# whm/middleware/admin_dual_session.py
from django.conf import settings
from django.contrib.sessions.backends.db import SessionStore
from users.database import get_user_data_by_id

class SeparateAdminSessionMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Add admin session to request
        self.setup_admin_session(request)
        response = self.get_response(request)
        return self.handle_admin_session_response(request, response)

    def setup_admin_session(self, request):
        """Set up completely separate admin session"""
        admin_cookie_name = getattr(settings, 'ADMIN_SESSION_COOKIE_NAME', 'session_admin')
        admin_session_key = request.COOKIES.get(admin_cookie_name)
        
        # Create separate admin session store
        request.admin_session = SessionStore(admin_session_key)
        
        # Load admin user from admin session
        admin_user_id = request.admin_session.get('_auth_user_id')
        if admin_user_id:
            from django.contrib.auth import get_user_model
            User = get_user_model()
            try:
                request.admin_user = User.objects.get(id=admin_user_id)
            except User.DoesNotExist:
                request.admin_user = None
                request.admin_session.flush()
        else:
            request.admin_user = None

        # Load impersonated client user if recorded in admin session
        request.impersonated_user = None
        if request.admin_user:
            impersonated_user_id = request.admin_session.get('impersonated_user_id')
            if impersonated_user_id:
                from django.contrib.auth import get_user_model
                User = get_user_model()
                try:
                    request.impersonated_user = User.objects.get(id=impersonated_user_id)
                except User.DoesNotExist:
                    request.impersonated_user = None
                    if 'impersonated_user_id' in request.admin_session:
                        del request.admin_session['impersonated_user_id']
                        request.admin_session.modified = True

        # Fallback/sync: if impersonated_user is not in admin_session yet, but request.user is authenticated client distinct from admin_user
        if not request.impersonated_user and request.admin_user and hasattr(request, 'user') and request.user.is_authenticated:
            if request.user.id != request.admin_user.id:
                request.impersonated_user = request.user
                request.admin_session['impersonated_user_id'] = request.user.id
                request.admin_session.modified = True

        # WHM & Admin Scope vs Client Impersonation Binding:
        if request.admin_user and (request.path.startswith('/whm/') or request.GET.get('scope') == 'admin'):
            # Always bind request.user to admin_user inside /whm/ or ?scope=admin so admin views run with full admin privileges
            request.user = request.admin_user
        elif request.impersonated_user:
            # Inside user panel while impersonating: ALWAYS pin request.user to impersonated_user across all reloads/refreshes
            request.user = request.impersonated_user
            if hasattr(request, 'session'):
                if request.session.get('_auth_user_id') != str(request.impersonated_user.id):
                    request.session['_auth_user_id'] = str(request.impersonated_user.id)
                    request.session['_auth_user_backend'] = 'django.contrib.auth.backends.ModelBackend'
                    request.session.modified = True
        elif request.admin_user and hasattr(request, 'user') and not request.user.is_authenticated:
            # Fallback 1: If admin_user is authenticated via admin session, but request.user is not authenticated,
            # set request.user = request.admin_user
            request.user = request.admin_user

        # Fallback 2: If standard request.user is authenticated and is admin (whm=1 or superuser/staff),
        # but request.admin_user is not set (e.g. session_admin cookie missing/expired),
        # automatically populate request.admin_user and sync the admin session
        if not request.admin_user and hasattr(request, 'user') and request.user.is_authenticated:
            is_whm_admin = False
            if getattr(request.user, 'is_superuser', False) or getattr(request.user, 'is_staff', False):
                is_whm_admin = True
            else:
                user_data = get_user_data_by_id(request.user.id)
                if user_data and user_data.get('whm') == 1:
                    is_whm_admin = True
            
            if is_whm_admin:
                request.admin_user = request.user
                if hasattr(request, 'admin_session'):
                    request.admin_session['_auth_user_id'] = str(request.user.id)
                    request.admin_session['_auth_user_backend'] = 'django.contrib.auth.backends.ModelBackend'
                    request.admin_session.modified = True

    def handle_admin_session_response(self, request, response):
        """Handle admin session cookie"""
        admin_cookie_name = getattr(settings, 'ADMIN_SESSION_COOKIE_NAME', 'session_admin')
        
        if hasattr(request, 'admin_session'):
            if request.admin_session.modified:
                if request.admin_session._session:
                    request.admin_session.save()

                    remember_me = request.admin_session.get('remember_me', False)
                    if hasattr(request, 'session'):
                        remember_me = remember_me or request.session.get('remember_me', False)

                    if remember_me:
                        cookie_max_age = getattr(settings, 'ADMIN_SESSION_COOKIE_AGE', getattr(settings, 'SESSION_REMEMBER_ME_AGE', 60 * 60 * 24 * 30))
                    else:
                        cookie_max_age = None  # Session cookie: expires when browser closes

                    response.set_cookie(
                        admin_cookie_name,
                        request.admin_session.session_key,
                        max_age=cookie_max_age,
                        path=getattr(settings, 'SESSION_COOKIE_PATH', '/'),
                        domain=getattr(settings, 'SESSION_COOKIE_DOMAIN', None),
                        secure=getattr(settings, 'ADMIN_SESSION_COOKIE_SECURE', settings.SESSION_COOKIE_SECURE),
                        httponly=getattr(settings, 'ADMIN_SESSION_COOKIE_HTTPONLY', settings.SESSION_COOKIE_HTTPONLY),
                        samesite=getattr(settings, 'ADMIN_SESSION_COOKIE_SAMESITE', settings.SESSION_COOKIE_SAMESITE),
                    )
                else:
                    response.delete_cookie(
                        admin_cookie_name,
                        path=getattr(settings, 'SESSION_COOKIE_PATH', '/'),
                        domain=getattr(settings, 'SESSION_COOKIE_DOMAIN', None)
                    )
        
        return response