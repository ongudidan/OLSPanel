import json
import os
import re
import subprocess
import tempfile

MODULE_SO = "/usr/local/lsws/modules/htaccess_compat.so"
OLS_CONFIG = "/usr/local/lsws/conf/httpd_config.conf"
INSTALL_URL = "https://olspanel.com/extra/install_ht.sh"
MARKERS = (
    "/usr/local/lsws/Example/html/mypanel/etc/version",
    "/usr/local/olspanel/mypanel/etc/version",
)
MODULE_BLOCK = re.compile(
    r"(?ms)^\s*module\s+htaccess_compat\s*\{.*?^\s*\}"
)
LS_ENABLED = re.compile(r"(?m)^\s*ls_enabled\s+([01])(?:\s*(?:#.*)?)?$")


def is_olspanel():
    return any(os.path.exists(path) for path in MARKERS)


def get_status():
    status = {
        "olspanel": is_olspanel(),
        "installed": os.path.isfile(MODULE_SO),
        "enabled": False,
        "module_block": False,
    }
    if not os.path.isfile(OLS_CONFIG):
        status["message"] = "OpenLiteSpeed configuration not found."
        return status
    try:
        with open(OLS_CONFIG, "r", encoding="utf-8") as config_file:
            contents = config_file.read()
    except OSError as exc:
        status["message"] = str(exc)
        return status
    block = MODULE_BLOCK.search(contents)
    if block:
        status["module_block"] = True
        enabled = LS_ENABLED.search(block.group(0))
        status["enabled"] = bool(enabled and enabled.group(1) == "1")
    else:
        status["message"] = "htaccess_compat module block not found."
    return status


def _run(command, input_text=None, timeout=180):
    try:
        result = subprocess.run(
            command,
            input=input_text,
            text=True,
            capture_output=True,
            check=False,
            timeout=timeout,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return False, str(exc)
    return result.returncode == 0, (result.stdout + result.stderr).strip()


def install():
    return _run_panel_command("install")


def uninstall():
    return _run_panel_command("uninstall")


def enable():
    return _set_enabled(True)


def disable():
    return _set_enabled(False)


def _set_enabled(enabled):
    if not is_olspanel():
        return {"status": "error", "message": "OLSPanel marker not found."}
    if not os.path.isfile(MODULE_SO):
        return {"status": "error", "message": "htaccess_compat is not installed."}
    if not os.path.isfile(OLS_CONFIG):
        return {"status": "error", "message": "OpenLiteSpeed configuration not found."}
    try:
        with open(OLS_CONFIG, "r", encoding="utf-8") as config_file:
            contents = config_file.read()
    except OSError as exc:
        return {"status": "error", "message": str(exc)}

    block = MODULE_BLOCK.search(contents)
    if not block:
        return {"status": "error", "message": "htaccess_compat module block not found."}
    value = "1" if enabled else "0"
    module_text = block.group(0)
    setting = LS_ENABLED.search(module_text)
    if setting:
        line = setting.group(0)
        replacement = re.sub(r"[01]", value, line, count=1)
        module_text = module_text[:setting.start()] + replacement + module_text[setting.end():]
    else:
        module_text = module_text.replace("{", "{\n    ls_enabled " + value, 1)
    updated = contents[:block.start()] + module_text + contents[block.end():]

    try:
        mode = os.stat(OLS_CONFIG).st_mode & 0o777
        with tempfile.NamedTemporaryFile(
            "w", encoding="utf-8", dir=os.path.dirname(OLS_CONFIG), delete=False
        ) as temporary:
            temporary.write(updated)
            temporary.flush()
            temporary_path = temporary.name
        os.chmod(temporary_path, mode)
        os.replace(temporary_path, OLS_CONFIG)
    except OSError as exc:
        try:
            os.unlink(temporary_path)
        except (OSError, UnboundLocalError):
            pass
        return {"status": "error", "message": str(exc)}

    restarted, output = _restart_ols()
    if not restarted:
        return {"status": "error", "message": "Configuration changed but OLS restart failed: " + (output or "")}
    return {
        "status": "success",
        "message": "htaccess_compat " + ("enabled" if enabled else "disabled") + ".",
        "enabled": enabled,
    }


def _restart_ols():
    for service in ("lsws", "lshttpd.service"):
        ok, output = _run(["systemctl", "restart", service], timeout=60)
        if ok:
            return True, output
    return False, output


def _run_panel_command(action):
    if action not in ("install", "uninstall"):
        return {"status": "error", "message": "Invalid action."}
    if not is_olspanel():
        return {"status": "error", "message": "OLSPanel marker not found."}
    downloaded, script = _run(["curl", "-sSL", INSTALL_URL], timeout=60)
    if not downloaded:
        return {"status": "error", "message": script or "Could not download installer."}
    script = "\n".join(line.rstrip("\r") for line in script.splitlines()) + "\n"
    arguments = ["bash", "-s", action]
    if action == "install":
        arguments.append("htaccess_compat")
    completed, output = _run(arguments, input_text=script)
    if not completed:
        return {"status": "error", "message": output or "OLSPanel command failed."}
    result = get_status()
    result.update({"status": "success", "message": "OLSPanel command completed.", "output": output})
    return result


def as_json():
    return json.dumps(get_status())

