#!/bin/bash
# -------------------------------------------------
# MongoDB Dynamic Setup Script with Named Parameters
# -------------------------------------------------

AUTH_DB="admin"
CREATE_DB=false
DROP_DB=true

# --- Parse arguments ---
while [[ "$#" -gt 0 ]]; do
  case "$1" in
    --create_db) CREATE_DB=true; shift 1 ;;
	--change_pass) CHANGE_PASS=true; shift 1 ;;
    --db) DB_NAME="$2"; shift 2 ;;
    --admin_user) ADMIN_USER="$2"; shift 2 ;;
    --admin_pass) ADMIN_PASS="$2"; shift 2 ;;
    --second_user) SECOND_USER="$2"; shift 2 ;;
    --second_pass) SECOND_PASS="$2"; shift 2 ;;
    --no-drop) DROP_DB=false; shift 1 ;;
    *) echo "❌ Unknown parameter: $1"; exit 1 ;;
  esac
done

# --- Change existing user password ---
if [ "$CHANGE_PASS" = true ]; then
  if [ -z "$DB_NAME" ] || [ -z "$ADMIN_USER" ] || [ -z "$ADMIN_PASS" ] || [ -z "$SECOND_USER" ] || [ -z "$SECOND_PASS" ]; then
    echo "Missing parameters for password change."
    echo "Usage: ./mongo_setup.sh --change_pass --db <database> --admin_user <user> --admin_pass <pass> --second_user <user> --second_pass <new_pass>"
    exit 1
  fi

echo "🔹 Checking if user '$SECOND_USER' exists in database '$DB_NAME'..."
  USER_EXISTS=$(mongosh --quiet --username "$ADMIN_USER" --authenticationDatabase "$AUTH_DB" --password "$ADMIN_PASS" --eval "
    db = db.getSiblingDB('$DB_NAME');
    db.getUser('$SECOND_USER') ? 'yes' : 'no';
  ")

  if [ "$USER_EXISTS" = "no" ]; then
    echo "User '$SECOND_USER' not found in database '$DB_NAME'."
    exit 1
  fi

  echo "🔐 Changing password for user '$SECOND_USER' in database '$DB_NAME'..."
  mongosh --quiet --username "$ADMIN_USER" --authenticationDatabase "$AUTH_DB" --password "$ADMIN_PASS" --eval "
    db = db.getSiblingDB('$DB_NAME');
    db.updateUser('$SECOND_USER', { pwd: '$SECOND_PASS' });
    print('✅ Password updated successfully for user: $SECOND_USER');
  "

  if [ $? -eq 0 ]; then
    echo "Password change completed successfully."
    exit 0
  else
    echo "Password change failed."
    exit 1
  fi
fi



# --- Validate required parameters ---
if [ "$CREATE_DB" = true ]; then
  if [ -z "$DB_NAME" ] || [ -z "$ADMIN_USER" ] || [ -z "$ADMIN_PASS" ] || [ -z "$SECOND_USER" ] || [ -z "$SECOND_PASS" ]; then
    echo "Missing required parameters."
    echo "Usage: ./mongo_setup.sh --create_db --db <database> --admin_user <user> --admin_pass <pass> --second_user <user> --second_pass <pass>"
    exit 1
  fi

 
  echo

  # --- Check if database already exists ---
  DB_EXISTS=$(mongosh --quiet --username "$ADMIN_USER" --authenticationDatabase "$AUTH_DB" --password "$ADMIN_PASS" --eval "
    db.getMongo().getDBNames().includes('$DB_NAME') ? 'yes' : 'no';
  ")

  if [ "$DB_EXISTS" = "yes" ]; then
    echo "Database '$DB_NAME' already exists."
    exit 1
  fi

  # --- Check if secondary user already exists anywhere ---
  USER_EXISTS=$(mongosh --quiet --username "$ADMIN_USER" --authenticationDatabase "$AUTH_DB" --password "$ADMIN_PASS" --eval "
    db = db.getSiblingDB('$DB_NAME');
    db.getUser('$SECOND_USER') ? 'yes' : 'no';
  ")

  if [ "$USER_EXISTS" = "yes" ]; then
    echo "User '$SECOND_USER' already exists in database '$DB_NAME'."
    exit 1
  fi

  # --- Create new database and user ---
  echo "Creating database '$DB_NAME' and user '$SECOND_USER'..."
  mongosh --quiet --username "$ADMIN_USER" --authenticationDatabase "$AUTH_DB" --password "$ADMIN_PASS" --eval "
    db = db.getSiblingDB('$DB_NAME');
    db.createUser({
      user: '$SECOND_USER',
      pwd: '$SECOND_PASS',
      roles: [ { role: 'readWrite', db: '$DB_NAME' } ]
    });
    db.createCollection('olspanel');
    db.olspanel.insertOne({ message: 'Welcome to $DB_NAME', createdAt: new Date() });
    print('Created database and user successfully.');
  "

  if [ $? -eq 0 ]; then
    echo "MongoDB setup complete for database: $DB_NAME"
  else
    echo "MongoDB setup failed."
    exit 1
  fi

else
  echo "No --create_db flag provided. Nothing to do."
  exit 0
fi
