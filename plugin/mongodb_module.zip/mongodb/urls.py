from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='example_index'),
    path('db_make/', views.mdb_make, name='mdb_make'),
    path('mongo_users_view/', views.mongo_users_view, name='mongo_users_view'),
    path('mongo_repair_view/<str:db_name>/', views.mongo_repair_view, name='mongo_repair_view'),
    path('mongo_delete_view/<str:db_name>/', views.mongo_delete_view, name='mongo_delete_view'),
    path('phpmymongo/', views.phpmymongo, name='phpmymongo'),
    path('mdb_pass/<str:db>/', views.mdb_pass, name='mdb_pass'),
    path('adminphpmymongo/', views.adminphpmymongo, name='adminphpmymongo'),
    path('home/', views.home, name='mhome'),
    path('admin_home/', views.admin_home, name='mhomea'),


]
