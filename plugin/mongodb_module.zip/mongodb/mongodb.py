import subprocess
import re
import json
from django.conf import settings
import os
import base64
import random
import string


    
    
def pg_size_to_bytes(size_str):
    """Convert MongoDB or PostgreSQL style size strings (e.g., 40.00 K, 8.0 KiB, 2 MB, etc.) to bytes."""
    size_str = size_str.strip().upper()

    # Normalize variants
    size_str = size_str.replace("KIB", "KB").replace("MIB", "MB").replace("GIB", "GB").replace("TIB", "TB")

    # Handle cases like "40.00 K"
    if size_str.endswith(" K"):
        size_str = size_str.replace(" K", "KB")
    elif size_str.endswith(" M"):
        size_str = size_str.replace(" M", "MB")
    elif size_str.endswith(" G"):
        size_str = size_str.replace(" G", "GB")

    # Remove double spaces
    size_str = re.sub(r"\s+", "", size_str)

    try:
        if size_str.endswith("KB"):
            return float(size_str[:-2]) * 1024
        elif size_str.endswith("MB"):
            return float(size_str[:-2]) * 1024**2
        elif size_str.endswith("GB"):
            return float(size_str[:-2]) * 1024**3
        elif size_str.endswith("TB"):
            return float(size_str[:-2]) * 1024**4
        elif size_str.endswith("BYTES"):
            return float(size_str[:-5])
        else:
            return float(size_str)  # fallback
    except ValueError:
        return 0.0


def bytes_to_pretty(num_bytes):
    """Convert bytes to human-readable format."""
    for unit in ["bytes", "KB", "MB", "GB", "TB"]:
        if num_bytes < 1024:
            return f"{num_bytes:.2f} {unit}"
        num_bytes /= 1024
    return f"{num_bytes:.2f} PB" 

def mongo_filter(prefix):
    admin_pass = get_phpmymongo_password("admin")
    admin_user = "admin"
    auth_db = "admin"

    if not all([prefix, admin_user, admin_pass, auth_db]):
        return {"error": "Missing required parameters."}

    try:
        cmd = [
            "mongosh", "--quiet",
            "--username", admin_user,
            "--password", admin_pass,
            "--authenticationDatabase", auth_db,
            "--eval", "show dbs"
        ]
        mongo_output = subprocess.check_output(cmd, text=True, stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError as e:
        return {"error": f"MongoDB connection failed: {e}"}

    filtered_dbs = []
    total_size_mb = 0.0

    for line in mongo_output.strip().splitlines():
        # match pattern: mydb   8.00 KiB
        match = re.match(r"^(\S+)\s+([\d.]+\s+\S+)$", line)
        if match:
            db_name, db_size = match.groups()
            if db_name.startswith(prefix):
                filtered_dbs.append({"db_name": db_name, "size_display": db_size})
                total_size_mb += pg_size_to_bytes(db_size)

    return {
        "prefix": prefix,
        "matched": len(filtered_dbs),
        "databases": filtered_dbs,
        "total_size": bytes_to_pretty(total_size_mb)
    }



def mongo_total_info():
    admin_pass = get_phpmymongo_password("admin")
    admin_user = "admin"
    auth_db = "admin"

    if not all([admin_user, admin_pass, auth_db]):
        return {"error": "Missing required parameters."}

    try:
        cmd = [
            "mongosh", "--quiet",
            "--username", admin_user,
            "--password", admin_pass,
            "--authenticationDatabase", auth_db,
            "--eval", "show dbs"
        ]
        mongo_output = subprocess.check_output(cmd, text=True, stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError as e:
        return {"error": f"MongoDB connection failed: {e}"}

    db_count = 0
    total_size_bytes = 0.0
    exclude_dbs = {"admin", "config", "local"}

    for line in mongo_output.strip().splitlines():
        # Example: mydb   8.00 KiB
        match = re.match(r"^(\S+)\s+([\d.]+\s+\S+)$", line)
        if match:
            db_name, db_size = match.groups()

            # Skip excluded databases
            if db_name in exclude_dbs:
                continue

            db_count += 1
            total_size_bytes += pg_size_to_bytes(db_size)

    return {
        "total_databases": db_count,
        "total_size": bytes_to_pretty(total_size_bytes)
    }



def get_users_for_databases(databases):
    admin_pass = get_phpmymongo_password("admin")
    admin_user = "admin"        
    auth_db = "admin"
    results = []

    # Regex to capture `user: 'username'`
    USER_REGEX = r"user:\s*'([^']+)'"

    for dbinfo in databases:
        db_name = dbinfo.get("db_name")
        size_display = dbinfo.get("size_display", "—")

        cmd = [
            "mongosh", "--quiet",
            "--username", admin_user,
            "--password", admin_pass,
            "--authenticationDatabase", auth_db,
            "--eval", f'db.getSiblingDB("{db_name}").getUsers();'
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            output = result.stdout.strip()

            # Extract usernames from mongosh output
            users = re.findall(USER_REGEX, output)

            results.append({
                "database": {
                    "db_name": db_name,
                    "size_display": size_display
                },
                "users": users if users else [],
                "raw_output": output if not users else None
            })

        except subprocess.CalledProcessError as e:
            results.append({
                "database": {
                    "db_name": db_name,
                    "size_display": size_display
                },
                "users": [],
                "error": f"Failed to fetch users: {e.stderr.strip() or str(e)}"
            })

    return {"status": "success", "data": results}


def repair_mongo_database(db_name):
    admin_pass = get_phpmymongo_password("admin")
    admin_user = "admin"        
    auth_db = "admin"
    cmd = [
        "mongosh", "--quiet",
        "--username", admin_user,
        "--password", admin_pass,
        "--authenticationDatabase", auth_db,
        "--eval", f'db.getSiblingDB("{db_name}").repairDatabase();'
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        output = result.stdout.strip()

        # Detect success based on typical response pattern
        if '"ok"' in output or "ok:" in output or "1" in output:
            status = "success"
            message = f"Database '{db_name}' repaired successfully."
        else:
            status = "warning"
            message = f"Database '{db_name}' repair completed with unusual output."

        return {
            "status": status,
            "database": db_name,
            "output": output,
            "message": message
        }

    except subprocess.CalledProcessError as e:
        return {
            "status": "error",
            "database": db_name,
            "message": f"Repair failed for database '{db_name}': {e.stderr.strip() or e.stdout.strip()}",
        }
        
        
        
def delete_database(db_name):
    admin_pass = get_phpmymongo_password("admin")
    admin_user = "admin"        
    auth_db = "admin"
    try:
        cmd = [
            "mongosh", "--quiet",
            "--username", admin_user,
            "--password", admin_pass,
            "--authenticationDatabase", auth_db,
            "--eval", f"db.getSiblingDB('{db_name}').dropDatabase()"
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0:
            return {"status": "success", "message": f"Database '{db_name}' deleted successfully."}
        else:
            return {"status": "error", "message": result.stderr.strip() or "Unknown error"}
    except Exception as e:
        return {"status": "error", "message": str(e)}        
        
        
def create_mongo_account(db_name, second_user, second_pass):
    admin_pass = get_phpmymongo_password("admin")
    admin_user = "admin"        
    #auth_db = "admin"
    try:
        script_path = os.path.join(settings.BASE_DIR, 'modules', 'mongodb', 'mongodb_cmd.sh')
        print("Step 2: Removing Windows-style line endings from upgrade.sh...")
        subprocess.run(f"sed -i 's/\\r$//' {script_path}", shell=True, check=True)

        print("Step 3: Running upgrade.sh...")
        subprocess.run(f"chmod +x {script_path}", shell=True)


        cmd = [
            "bash", script_path,
            "--create_db",
            "--db", db_name,
            "--admin_user", admin_user,
            "--admin_pass", admin_pass,
            "--second_user", second_user,
            "--second_pass", second_pass
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode == 0:
            store_user_password(second_user,second_pass)
            
            return {
                "status": "success",
                "message": f"Database '{db_name}' and user '{second_user}' created successfully.",
                "output": result.stdout.strip()
            }
        else:
            error_message = result.stderr.strip() or result.stdout.strip() or "Unknown error during account creation."

            return {
                "status": "error",
                "message": error_message,
                "output": result.stdout.strip()
            }

    except Exception as e:
        return {"status": "error", "message": str(e)}



def store_user_password(username, password):
    
    try:
        new_data = encodepass(password)
        django_root = settings.BASE_DIR
        etc_dir = os.path.join(django_root, 'etc')
        os.makedirs(etc_dir, exist_ok=True)

        password_file = os.path.join(etc_dir, f"phpmymongo_{username}")

        # Write or overwrite the password file
        with open(password_file, 'w') as f:
            f.write(new_data)

        return password_file

    except Exception as e:
        raise Exception(f"Error saving password: {str(e)}")        
        
        
        
def get_phpmymongo_password(username):
    # Get the path of the project directory
    django_root = settings.BASE_DIR
    if username == 'admin':
        source_file = os.path.join(django_root, 'etc', "mongodbPassword")
    else:
        source_file = os.path.join(django_root, 'etc', f"phpmymongo_{username}")
    
    # Check if the file exists
    if not os.path.exists(source_file):
        return f"Password file for user {username} not found."

    try:
        # Read the content of the file
        with open(source_file, 'r') as file:
            file_content = file.read()
        
        if username == 'admin':
            return file_content
        else:
            return decodepass(file_content)
            
        
    
    except Exception as e:
        # Handle unexpected errors and return the error message
        return f"An error occurred: {str(e)}"        
        
        
def encodepass(data: str) -> str:
    
    # Convert the string to bytes
    data_bytes = data.encode('utf-8')
    # Encode the bytes to Base64
    base64_bytes = base64.b64encode(data_bytes)
    # Convert Base64 bytes back to string
    base64_str = base64_bytes.decode('utf-8')
    # Generate a random 5-character string of lowercase letters
    random_string = ''.join(random.choices(string.ascii_lowercase, k=5))
    # Prepend the random string to the Base64 string
    return random_string + base64_str

def decodepass(base64_data: str) -> str:
    
    # Remove the first 5 characters (random string) from the string
    base64_str = base64_data[5:]
    # Convert Base64 string to bytes
    base64_bytes = base64_str.encode('utf-8')
    # Decode the Base64 bytes back to original bytes
    decoded_bytes = base64.b64decode(base64_bytes)
    # Convert bytes back to string
    return decoded_bytes.decode('utf-8')   

def change_mongo_password(db_name, second_user, second_pass):
    admin_pass = get_phpmymongo_password("admin")
    admin_user = "admin"        
    #auth_db = "admin"
    try:
        script_path = os.path.join(settings.BASE_DIR, 'modules', 'mongodb', 'mongodb_cmd.sh')

        # Fix line endings and ensure executable
        subprocess.run(f"sed -i 's/\\r$//' {script_path}", shell=True, check=True)
        subprocess.run(f"chmod +x {script_path}", shell=True, check=True)

        # Prepare command
        cmd = [
            "bash", script_path,
            "--change_pass",
            "--db", db_name,
            "--admin_user", admin_user,
            "--admin_pass", admin_pass,
            "--second_user", second_user,
            "--second_pass", second_pass
        ]

        # Execute shell script
        result = subprocess.run(cmd, capture_output=True, text=True)

        # Handle output
        if result.returncode == 0:
            store_user_password(second_user, second_pass)  # optional storage call
            return {
                "status": "success",
                "message": f"Password changed successfully for user '{second_user}'.",
                "output": result.stdout.strip()
            }
        else:
            error_message = result.stderr.strip() or result.stdout.strip() or "Unknown error during password change."
            return {
                "status": "error",
                "message": error_message,
                "output": result.stdout.strip()
            }

    except Exception as e:
        return {"status": "error", "message": str(e)}