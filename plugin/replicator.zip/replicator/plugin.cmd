#!/bin/bash

# Detect OLSPanel base directory
BASE_DIR="/usr/local/olspanel/mypanel"
if [ ! -d "$BASE_DIR" ]; then
  # Fallback to local discovery
  BASE_DIR="$(pwd)"
  if [ ! -f "$BASE_DIR/manage.py" ]; then
    BASE_DIR="$(dirname "$(dirname "$BASE_DIR")")"
  fi
fi

# Define source and destination paths
MODULE_SRC="$BASE_DIR/3rdparty/replicator/modules/replicator"
MODULE_DEST="$BASE_DIR/modules/replicator"
ICON_SRC="$BASE_DIR/3rdparty/replicator/plugin_icon.svg"
ICON_DEST="$BASE_DIR/media/icon/replicator.svg"

# Copy Django module to the system modules directory
if [ -d "$MODULE_SRC" ]; then
  mkdir -p "$MODULE_DEST"
  cp -rf "$MODULE_SRC"/* "$MODULE_DEST"/
  chown -R www-data:www-data "$MODULE_DEST" 2>/dev/null || true
  chmod -R 755 "$MODULE_DEST" 2>/dev/null || true
  echo "✅ Django replicator module copied to $MODULE_DEST"
elif [ -d "$MODULE_DEST" ]; then
  chown -R www-data:www-data "$MODULE_DEST" 2>/dev/null || true
  chmod -R 755 "$MODULE_DEST" 2>/dev/null || true
  echo "✅ Django replicator module already present at $MODULE_DEST"
else
  echo "❌ Error: Django replicator module source not found: $MODULE_SRC"
  exit 1
fi

# Deploy SVG vector icon
if [ -f "$ICON_SRC" ]; then
  mkdir -p "$(dirname "$ICON_DEST")"
  cp -f "$ICON_SRC" "$ICON_DEST"
  chown www-data:www-data "$ICON_DEST" 2>/dev/null || true
  chmod 644 "$ICON_DEST" 2>/dev/null || true
  echo "✅ SVG vector icon deployed to $ICON_DEST"
elif [ -f "$ICON_DEST" ]; then
  chown www-data:www-data "$ICON_DEST" 2>/dev/null || true
  chmod 644 "$ICON_DEST" 2>/dev/null || true
  echo "✅ SVG vector icon already deployed to $ICON_DEST"
else
  echo "⚠️ Warning: SVG icon source not found: $ICON_SRC"
fi

# Deploy Plugin Configuration
CONF_SRC="$BASE_DIR/3rdparty/replicator/replicator.conf"
if [ ! -f "$CONF_SRC" ]; then
  CONF_SRC="$BASE_DIR/3rdparty/replicator/plugin_replicator.conf"
fi
CONF_DEST="$BASE_DIR/plugin/replicator.conf"

if [ -f "$CONF_SRC" ]; then
  mkdir -p "$BASE_DIR/plugin"
  cp -f "$CONF_SRC" "$CONF_DEST"
  chown www-data:www-data "$CONF_DEST"
  echo "✅ Plugin config deployed to $CONF_DEST"
fi

# Ensure log directory exists and is writable by panel user (www-data)
MIGRATION_LOG_DIR="/var/log/olspanel-migration"
mkdir -p "$MIGRATION_LOG_DIR"
chown -R www-data:www-data "$MIGRATION_LOG_DIR"
chmod -R 775 "$MIGRATION_LOG_DIR"
echo "✅ Log directory initialized at $MIGRATION_LOG_DIR"

# Restart the panel service asynchronously to load the new module
if systemctl is-active --quiet cp 2>/dev/null; then
  (sleep 2 && systemctl restart cp) &
  echo "🔄 Scheduled OLSPanel backend restart..."
fi

echo "🎉 Server Replicator installation script completed successfully."
