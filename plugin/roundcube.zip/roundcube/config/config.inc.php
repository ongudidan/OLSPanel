<?php

/* Local configuration for Roundcube Webmail */

// ----------------------------------
// SQL DATABASE
// ----------------------------------
// Database connection string (DSN) for read+write operations
// Format (compatible with PEAR MDB2): db_provider://user:password@host/database
// Currently supported db_providers: mysql, pgsql, sqlite, mssql, sqlsrv, oracle
// For examples see https://pear.php.net/manual/en/package.database.mdb2.intro-dsn.php
// Note: for SQLite use absolute path (Linux): 'sqlite:////full/path/to/sqlite.db?mode=0646'
//       or (Windows): 'sqlite:///C:/full/path/to/sqlite.db'
// Note: Various drivers support various additional arguments for connection,
//       for Mysql: key, cipher, cert, capath, ca, verify_server_cert,
//       for Postgres: application_name, sslmode, sslcert, sslkey, sslrootcert, sslcrl, sslcompression, service.
//       e.g. 'mysql://roundcube:@localhost/roundcubemail?verify_server_cert=false'
//$config['db_dsnw'] = 'sqlite:////usr/local/lsws/Example/html/mypanel/3rdparty/round/db.db?mode=0646';
$panel_user = !empty($_SERVER['PANEL_USERNAME']) ? trim($_SERVER['PANEL_USERNAME']) : '';
if ($panel_user === 'root') {
    $root_path = '/root';
    $target_db = '/root/etc/rcube.db';
} elseif ($panel_user && is_dir('/home/' . $panel_user)) {
    $root_path = '/home/' . $panel_user;
    $target_db = '/home/' . $panel_user . '/etc/rcube.db';
} else {
    $root_path = dirname(__DIR__);
    $target_db = dirname(__DIR__) . '/config/rcube.db';
}

$root_db = dirname($target_db);
$source_db = dirname(__FILE__) . '/db.db';

if (!file_exists($target_db)) {
    if (!is_dir($root_db)) {
        @mkdir($root_db, 0777, true);
    }
    if (file_exists($source_db)) {
        @copy($source_db, $target_db);
        @chmod($target_db, 0666);
    }
}
if (file_exists($target_db) && !is_writable($target_db)) {
    @chmod($target_db, 0666);
}

$config['db_dsnw'] = 'sqlite:///' . $target_db . '?mode=0666';
$config['log_dir'] = dirname(__DIR__) . '/logs/';
$config['temp_dir'] = dirname(__DIR__) . '/temp/';
$panel_user = !empty($_SERVER['PANEL_USERNAME']) ? trim($_SERVER['PANEL_USERNAME']) : '';
if ($panel_user === 'root') {
    $root_path = '/root';
    $target_db = '/root/etc/rcube.db';
} elseif ($panel_user && is_dir('/home/' . $panel_user)) {
    $root_path = '/home/' . $panel_user;
    $target_db = '/home/' . $panel_user . '/etc/rcube.db';
} else {
    $root_path = dirname(__DIR__);
    $target_db = dirname(__DIR__) . '/config/rcube.db';
}

$root_db = dirname($target_db);
$source_db = dirname(__FILE__) . '/db.db';

if (!file_exists($target_db)) {
    if (!is_dir($root_db)) {
        @mkdir($root_db, 0777, true);
    }
    if (file_exists($source_db)) {
        @copy($source_db, $target_db);
        @chmod($target_db, 0666);
    }
}
if (file_exists($target_db) && !is_writable($target_db)) {
    @chmod($target_db, 0666);
}

$config['db_dsnw'] = 'sqlite:///' . $target_db . '?mode=0666';
$config['log_dir'] = dirname(__DIR__) . '/logs/';
$config['temp_dir'] = dirname(__DIR__) . '/temp/';
$panel_user = !empty($_SERVER['PANEL_USERNAME']) ? trim($_SERVER['PANEL_USERNAME']) : '';
if ($panel_user === 'root') {
    $root_path = '/root';
    $target_db = '/root/etc/rcube.db';
} elseif ($panel_user && is_dir('/home/' . $panel_user)) {
    $root_path = '/home/' . $panel_user;
    $target_db = '/home/' . $panel_user . '/etc/rcube.db';
} else {
    $root_path = dirname(__DIR__);
    $target_db = dirname(__DIR__) . '/config/rcube.db';
}

$root_db = dirname($target_db);
$source_db = dirname(__FILE__) . '/db.db';

if (!file_exists($target_db)) {
    if (!is_dir($root_db)) {
        @mkdir($root_db, 0777, true);
    }
    if (file_exists($source_db)) {
        @copy($source_db, $target_db);
        @chmod($target_db, 0666);
    }
}
if (file_exists($target_db) && !is_writable($target_db)) {
    @chmod($target_db, 0666);
}

$config['db_dsnw'] = 'sqlite:///' . $target_db . '?mode=0666';
$config['log_dir'] = dirname(__DIR__) . '/logs/';
$config['temp_dir'] = dirname(__DIR__) . '/temp/';
$panel_user = !empty($_SERVER['PANEL_USERNAME']) ? trim($_SERVER['PANEL_USERNAME']) : '';
if ($panel_user === 'root') {
    $root_path = '/root';
    $target_db = '/root/etc/rcube.db';
} elseif ($panel_user && is_dir('/home/' . $panel_user)) {
    $root_path = '/home/' . $panel_user;
    $target_db = '/home/' . $panel_user . '/etc/rcube.db';
} else {
    $root_path = dirname(__DIR__);
    $target_db = dirname(__DIR__) . '/config/rcube.db';
}

$root_db = dirname($target_db);
$source_db = dirname(__FILE__) . '/db.db';

if (!file_exists($target_db)) {
    if (!is_dir($root_db)) {
        @mkdir($root_db, 0777, true);
    }
    if (file_exists($source_db)) {
        @copy($source_db, $target_db);
        @chmod($target_db, 0666);
    }
}
if (file_exists($target_db) && !is_writable($target_db)) {
    @chmod($target_db, 0666);
}

$config['db_dsnw'] = 'sqlite:///' . $target_db . '?mode=0666';
$config['log_dir'] = dirname(__DIR__) . '/logs/';
$config['temp_dir'] = dirname(__DIR__) . '/temp/';

// Location of temporary saved files such as attachments and cache files
// must be writeable for the user who runs PHP process (Apache user if mod_php is being used)
$config['temp_dir'] = $root_path . 'tmp/';
//$config['db_dsnw'] = 'sqlite:///' . dirname(__FILE__) . '/db.db?mode=0646';

// ----------------------------------
// IMAP
// ----------------------------------
// The IMAP host (and optionally port number) chosen to perform the log-in.
// Leave blank to show a textbox at login, give a list of hosts
// to display a pulldown menu or set one host as string.
// Enter hostname with prefix ssl:// to use Implicit TLS, or use
// prefix tls:// to use STARTTLS.
// If port number is omitted it will be set to 993 (for ssl://) or 143 otherwise.
// Supported replacement variables:
// %n - hostname ($_SERVER['SERVER_NAME'])
// %t - hostname without the first part
// %d - domain (http hostname $_SERVER['HTTP_HOST'] without the first part)
// %s - domain name after the '@' from e-mail address provided at login screen
// For example %n = mail.domain.tld, %t = domain.tld
// WARNING: After hostname change update of mail_host column in users table is
//          required to match old user data records with the new host.
$config['imap_host'] = 'localhost:143';
$config['smtp_host'] = 'localhost:25';

// provide an URL where a user can get support for this Roundcube installation
// PLEASE DO NOT LINK TO THE ROUNDCUBE.NET WEBSITE HERE!
$config['support_url'] = '';

// This key is used for encrypting purposes, like storing of imap password
// in the session. For historical reasons it's called DES_key, but it's used
// with any configured cipher_method (see below).
// For the default cipher_method a required key length is 24 characters.
$config['des_key'] = 'WxVrGFKjyNryvFC5lGnM2CYl';

// ----------------------------------
// PLUGINS
// ----------------------------------
// List of active plugins (in plugins/ directory)
$config['plugins'] = ['olspanellogin'];

// the default locale setting (leave empty for auto-detection)
// RFC1766 formatted language name like en_US, de_DE, de_CH, fr_FR, pt_BR
$config['language'] = 'en_US';
//$config['enable_installer'] = false;
$config['smtp_log'] = false;
//$config['auto_create_user'] = false;
$config['log_driver'] = 'file';
$config['create_default_folders'] = true;

// protect the default folders from renames, deletes, and subscription changes
$config['protect_default_folders'] = true;
