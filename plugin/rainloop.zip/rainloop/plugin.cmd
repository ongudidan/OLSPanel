#!/bin/bash
sudo chown -R nobody:nobody /usr/local/lsws/Example/html/mypanel/3rdparty/rainloop/data
sudo chmod -R 755 /usr/local/lsws/Example/html/mypanel/3rdparty/rainloop/data