from django.contrib import messages
from django.shortcuts import redirect, render
from django.views.decorators.http import require_http_methods

from whm.decorators import *

from .lscache_owner import disable, enable, get_status, install, uninstall


@alogin_required
def index(request):
    if request.method == "POST":
        action = request.POST.get("action", "")
        if action == "install":
            result = install()
        elif action == "uninstall":
            result = uninstall()
        elif action == "save":
            result = enable() if request.POST.get("enabled") == "1" else disable()
        else:
            result = {"status": "error", "message": "Invalid action."}

        if result.get("status") == "success":
            messages.success(request, result.get("message", "Completed."))
        else:
            messages.error(request, result.get("message", "Failed."))
        return redirect("/module/lscache_owner/")

    return render(request, "lscache_owner/index.html", {"status": get_status()})


index = require_http_methods(["GET", "POST"])(index)

