<div class="operation">
	<?php render_server_menu("databases"); ?>
</div>


<table class="table-modern">
	<tr>
		<th><?php hm("name"); ?></th>
		<th><?php hm("size"); ?></th>
		<th nowrap><?php hm("storagesize"); ?></th>
		<th nowrap><?php hm("datasize"); ?></th>
		<th nowrap><?php hm("indexsize"); ?></th>
		<th><?php hm("collections"); ?></th>
		<th><?php hm("objects"); ?></th>
	</tr>
	<?php foreach ($dbs as $db):?>
	<tr>
		<td><a href="<?php h(url("db.index", array("db"=>$db["name"]))); ?>"><?php h($db["name"]);?></a></td>
		<td><?php h($db["diskSize"]);?></td>
		<td><?php h($db["storageSize"]);?></td>
		<td><?php h($db["dataSize"]);?></td>
		<td><?php h($db["indexSize"]);?></td>
		<td><?php h($db["collections"]);?></td>
		<td><?php h($db["objects"]);?></td>
	</tr>
	<?php endforeach; ?>
</table>
