<html>
    <head>
        <title>PhpMyMongo</title>
        <!-- Base Jquery -->
        <script language="javascript" type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
        <script language="javascript" type="text/javascript" src="js/jquery-ui-1.8.4.custom.min.js"></script>

        <!--JQuery Layout -->
        <script language="javascript" type="text/javascript" src="js/jquery.layout.min-1.3.0.js"></script>
        <link type="text/css" href="<?php render_theme_path() ?>/css/layout-default-1.3.0.css" rel="stylesheet" />
        <style type="text/css">
          
            #right-pane { padding-left:10px }
            
          .loading-bar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background-color: #28a745; /* Green color */
            z-index: 1000;
            display: none; /* Hidden by default */
        }

        /* Dialog styles */
        .dialog {
            display: none; /* Hidden by default */
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
            z-index: 1001;
            text-align: center;
            max-width: 300px;
        }
            
        </style>
        
        
        
        <script language="javascript">
            $(document).ready(function(){
                //---Init Layout
                var wsize=250;
                $('body').layout({
                    defaults: {
                        applyDefaultStyles: false

                    },
                    north :{
                        closable:true,
                        slidable:false
                    },
                    west: {
                        minSize: wsize,
                        maxSize: 2*wsize,
                        size: wsize,
                        resizable: true,
                        closable:true,
                        slidable:true
                    }

                });
            });

            /** show manual links **/
            function setManualPosition(className, x, y) {
                if ($(className).is(":visible")) {
                    $(className).hide();
                }
                else {
                    window.setTimeout(function () {
                        $(className).show();
                        $(className).css("left", x);
                        $(className).css("top", y)
                    }, 100);
                    $(className).find("a").click(function () {
                        hideMenus();
                    });
                }
            }
 
            /** hide menus **/
            function hideMenus() {
                $(".manual").hide();
                $(".server-menu").hide();
            }
        </script>
    </head>
    <body>
        <!-- top bar -->

        <div id="top-pane" class="ui-layout-north" style="overflow:hidden">
            <iframe src="<?php echo $topUrl; ?>" name="top" width="100%" frameborder="0" height="45" marginheight="0" scrolling="no" id="topframe"></iframe>
        </div>
        <div id="left-pane" class="ui-layout-west">
            <!-- left bar -->
            <iframe src="<?php echo $leftUrl; ?>" name="left" width="100%" height="100%" frameborder="0" scrolling="auto" marginheight="0" id="leftframe"></iframe>
        </div>

        <div id="right-pane" class="ui-layout-center">
            
          <!-- Modern loading popup -->
<!-- Simple loading bar -->
    <div id="loadingBar" class="loading-bar"></div>

    <!-- Dialog -->
    <div id="dialog" class="dialog">
        <p><span id="dialogLink">Loading please wait...</span></p>
    </div>

            <!-- right bar -->
            <iframe src="<?php echo $rightUrl; ?>" name="right" width="100%" height="100%" frameborder="0" marginheight="0" scrolling="auto" id="myFrame"></iframe>
        </div>

        <!-- quick links -->
        <div class="manual">
            <?php render_manual_items() ?>
        </div>

        <!-- menu when "Tools" clicked -->
        <div class="server-menu" style="width:120px">
            <a href="<?php h(url("server.index")); ?>" target="right"><?php hm("server"); ?></a><br/>
            <a href="<?php h(url("server.status")); ?>" target="right"><?php hm("status"); ?></a> <br/>
            <a href="<?php h(url("server.databases")); ?>" target="right"><?php hm("databases"); ?></a> <a href="<?php h(url("server.createDatabase")); ?>" target="right" title="Create new Database">[+]</a> <br/>
            <a href="<?php h(url("server.processlist")); ?>" target="right"><?php hm("processlist"); ?></a> <br/>
            <a href="<?php h(url("server.command")); ?>" target="right"><?php hm("command"); ?></a> <br/>
            <a href="<?php h(url("server.execute")); ?>" target="right"><?php hm("execute"); ?></a> <br/>
            <a href="<?php h(url("server.replication")); ?>" target="right"><?php hm("master_slave"); ?></a>
        </div>


<script>
        document.addEventListener('DOMContentLoaded', function() {
            const iframes = [
                { element: document.getElementById('topframe'), name: 'topframe' },
                { element: document.getElementById('leftframe'), name: 'leftframe' },
                { element: document.getElementById('myFrame'), name: 'myFrame' }
            ];
            const loadingBar = document.getElementById('loadingBar');
            const dialog = document.getElementById('dialog');
            const dialogLink = document.getElementById('dialogLink');

            // Check if all iframes exist
            for (const iframe of iframes) {
                if (!iframe.element) {
                    console.error(`Iframe with id "${iframe.name}" not found.`);
                    return;
                }
            }

            // Show loading bar on initial load for all iframes
            loadingBar.style.display = 'block';

            // Track loading iframes
            let loadingIframes = iframes.length;

            // Function to check if a link is internal (same origin)
            function isInternalLink(linkHref, iframe) {
                try {
                    const linkUrl = new URL(linkHref, iframe.contentDocument?.location.origin || window.location.origin);
                    const iframeUrl = new URL(iframe.src);
                    return linkUrl.hostname === iframeUrl.hostname;
                } catch (error) {
                    console.error('Error parsing URL:', error.message);
                    return false; // Treat invalid URLs as external
                }
            }

            // Function to attach click event listeners to links in an iframe
            function attachLinkListeners(iframe, iframeName) {
                try {
                    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                    if (!iframeDoc) {
                        console.error(`Cannot access contentDocument for iframe "${iframeName}".`);
                        return;
                    }

                    const links = iframeDoc.getElementsByTagName('a');
                    for (let link of links) {
                        link.addEventListener('click', function(event) {
                           if (link.hasAttribute('onclick')) {
                                console.log(`Ignoring link with onclick in ${iframeName}:`, link.href);
                                return;
                            }
                            if (!isInternalLink(link.href, iframe)) {
                                console.log(`Ignoring third-party link in ${iframeName}:`, link.href);
                                return;
                            }

                            // Show dialog with link URL
                            
                            dialog.style.display = 'block';
                            console.log(`Internal link clicked in ${iframeName}:`, link.href);

                            // Show loading bar for potential navigation
                            loadingBar.style.display = 'block';
                        });
                    }
                    console.log(`Link listeners attached to ${links.length} links in ${iframeName}.`);
                } catch (error) {
                    console.error(`Error accessing iframe content for ${iframeName}:`, error.message);
                }
            }

            // Handle iframe load events (initial or after link click)
            function handleIframeLoad(iframe, iframeName) {
                iframe.addEventListener('load', function() {
                    // Decrease loading iframes count
                    loadingIframes--;

                    // Hide loading bar when all iframes are loaded
                    if (loadingIframes === 0) {
                        loadingBar.style.display = 'none';
                    }

                    // Close dialog if open
                    if (dialog.style.display === 'block') {
                        dialog.style.display = 'none';
                    }

                    // Re-attach link listeners for new content
                    attachLinkListeners(iframe, iframeName);
                });
            }

            // Initialize each iframe
            iframes.forEach(iframe => {
                handleIframeLoad(iframe.element, iframe.name);
                // Attach initial link listeners
                attachLinkListeners(iframe.element, iframe.name);
            });
        });
    </script>
    </body>
</html>