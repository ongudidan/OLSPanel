<h3><?php render_navigation($db); ?> &raquo; <?php hm("import"); ?></h3>

<?php if (isset($error)):?> 
  <p class="error"><?php h($error);?></p>
<?php endif; ?>

<?php if (isset($message)):?> 
  <p class="message"><?php h($message);?></p>
  <script>
    window.parent.frames["left"].location.reload();
  </script>
<?php endif; ?>

<p><strong>Import:</strong></p>

<style>
.file-info strong {
  color: #0078d7;
  font-weight: bold;
  background: #e8f3ff;
  padding: 2px 6px;
  border-radius: 4px;
}
.upload-box {
  border: 2px dashed #aaa;
  border-radius: 6px;
  padding: 30px;
  text-align: center;
  color: #666;
  cursor: pointer;
  transition: all 0.2s;
  width: 420px;
  margin-bottom: 10px;
}
.upload-box.dragover {
  background-color: #f0f8ff;
  border-color: #00aaff;
  color: #00aaff;
}
.file-info {
  font-size: 13px;
  color: #333;
  margin-top: 5px;
}
.progress-container {
  width: 420px;
  background-color: #f5f5f5;
  border-radius: 6px;
  overflow: hidden;
  margin-top: 10px;
  display: none;
}
.progress-bar {
  height: 20px;
  background-color: #4caf50;
  width: 0%;
  transition: width 0.2s;
  text-align: center;
  color: white;
  font-size: 12px;
}
#responseBox {
  width: 420px;
  margin-top: 10px;
  font-weight: bold;
  white-space: pre-wrap; /* ✅ Keep newlines and spacing */
  word-break: break-word; /* ✅ Prevent overflow */
}
#responseBox.success {
  color: green;
}
#responseBox.error {
  color: red;
}
.limit-info {
  font-size: 12px;
  color: #888;
  margin-bottom: 10px;
}
</style>

<?php
$upload_max = ini_get('upload_max_filesize');
$post_max = ini_get('post_max_size');
?>

<div class="limit-info">
  <strong>Upload limits:</strong> upload_max_filesize = <code><?php echo $upload_max; ?></code>,
  post_max_size = <code><?php echo $post_max; ?></code>
</div>

<form id="importForm" method="post" enctype="multipart/form-data">
  <input type="hidden" name="format" value="js"/>
  
  <div id="dropArea" class="upload-box">
    <p>Drag & drop your <strong>.bjson</strong> or <strong>.zip</strong> file here<br/>or click to browse.</p>
    <input type="file" id="fileInput" name="json" accept=".bson,.json,.zip" style="display:none;"/>
    <div id="fileInfo" class="file-info"></div>
  </div>
  
  <input type="submit" value="<?php hm("import"); ?>"/>
  
  <div class="progress-container" id="progressContainer">
    <div class="progress-bar" id="progressBar">0%</div>
  </div>

  <div id="responseBox"></div>
</form>

<script>
const form = document.getElementById("importForm");
const fileInput = document.getElementById("fileInput");
const dropArea = document.getElementById("dropArea");
const progressContainer = document.getElementById("progressContainer");
const progressBar = document.getElementById("progressBar");
const responseBox = document.getElementById("responseBox");
const fileInfo = document.getElementById("fileInfo");

// --- Drag & Drop events ---
dropArea.addEventListener("click", () => fileInput.click());
dropArea.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropArea.classList.add("dragover");
});
dropArea.addEventListener("dragleave", () => dropArea.classList.remove("dragover"));
dropArea.addEventListener("drop", (e) => {
  e.preventDefault();
  dropArea.classList.remove("dragover");
  if (e.dataTransfer.files.length > 0) {
    fileInput.files = e.dataTransfer.files;
    showFileInfo();
  }
});

fileInput.addEventListener("change", showFileInfo);

function showFileInfo() {
  const file = fileInput.files[0];
  if (file) {
    const sizeMB = (file.size / 1024 / 1024).toFixed(2);
    fileInfo.innerHTML = `Selected: <strong>${file.name}</strong> (${sizeMB} MB)`; // ✅ highlight name
  } else {
    fileInfo.textContent = "";
  }
}


// --- Upload with Progress ---
form.addEventListener("submit", function(e) {
  e.preventDefault();
  const file = fileInput.files[0];
  if (!file) {
    alert("Please select a file to import.");
    return;
  }

  const formData = new FormData(this);
  const xhr = new XMLHttpRequest();
  xhr.open("POST", this.action || window.location.href, true);

  progressContainer.style.display = "block";
  progressBar.style.width = "0%";
  progressBar.textContent = "0%";
  responseBox.textContent = "";
  responseBox.className = "";

  xhr.upload.onprogress = function(e) {
    if (e.lengthComputable) {
      const percent = Math.round((e.loaded / e.total) * 100);
      progressBar.style.width = percent + "%";
      progressBar.textContent = percent + "%";
    }
  };

 xhr.onload = function() {
  try {
    // Some responses might already be HTML with <br />
    let respText = xhr.responseText.trim();

    // Try to parse JSON first
    let resp = null;
    try {
      resp = JSON.parse(respText);
    } catch {}

    progressContainer.style.display = "block";

    if (resp && typeof resp === "object") {
      if (resp.status === "success") {
        progressBar.style.backgroundColor = "#4caf50";
        progressBar.textContent = "100%";
        responseBox.className = "success";
        responseBox.innerHTML = resp.message.replace(/\n/g, "<br>"); // ✅ keep line breaks
      } else {
        progressBar.style.backgroundColor = "#f44336";
        responseBox.className = "error";
        responseBox.innerHTML = resp.message.replace(/\n/g, "<br>");
      }
    } else {
      // not JSON, treat as raw HTML with <br> separators
      responseBox.className = "";
      responseBox.innerHTML = respText
        .replace(/\\n/g, "<br>")
        .replace(/\r/g, "")
        .replace(/<\/body>[\s\S]*/i, ""); // strip trailing HTML if any
    }
  } catch (err) {
    progressBar.style.backgroundColor = "#f44336";
    responseBox.className = "error";
    responseBox.textContent = "Invalid server response.";
  }
};


  xhr.onerror = function() {
    progressBar.style.backgroundColor = "#f44336";
    responseBox.className = "error";
    responseBox.textContent = "Error during upload!";
  };

  xhr.send(formData);
});
</script>
