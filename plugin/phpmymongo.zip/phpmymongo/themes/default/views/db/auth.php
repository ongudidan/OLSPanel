<h3><?php render_navigation($db); ?> &raquo; <?php hm("authentication"); ?></h3>

<div class="operation">
	<a href="<?php h(url("db.auth", array("db"=>$db))); ?>" class="current">Users</a> |
	<a href="<?php h(url("db.addUser", array("db"=>$db))); ?>">Add User</a>
</div>

<table bgcolor="#cccccc" cellpadding="2" cellspacing="1" width="600">
	<tr>
		<th>ID</th>
		<th>User</th>
		<th>Read Only</th>
		<th>Operation</th>
	</tr>
	<?php foreach ($users as $user): ?>
	<tr bgcolor="#f0f0f0">
		<td width="120" ><?php h($user["_id"]);?></td>
		<td><?php h($user["user"]);?></td>
		<th><?php if(isset($user["readOnly"])):h($user["readOnly"] ? "Y":""); endif; ?></th>
		<th><a href="<?php h(url("db.deleteUser", array("db"=>$db,"user"=>$user["user"]))); ?>" onclick="return window.confirm('Are you sure to remove user \'<?php h($user["user"]); ?>\'?')">Remove</a></th>
	</tr>
	<?php endforeach; ?>
</table>

<p style="margin-top:60px">
	<a href="http://docs.mongodb.org/manual/tutorial/enable-authentication/" target="_blank">Official Document: Enable Authentication</a>
</p>