<script language="javascript">

/** show more menus **/
function showMoreMenus(link) {
	var obj = $(link);
	setManualPosition(".menu", obj.position().left, obj.position().top + obj.height() + 4);
}


/** show manual links **/
function setManualPosition(className, x, y) {
	if ($(className).is(":visible")) {
		$(className).hide();
	}
	else {
		window.setTimeout(function () {
			$(className).show();
			$(className).css("left", x);
			$(className).css("top", y)
		}, 100);
		$(className).find("a").click(function () {
			hideMenus();
		});
	}
}

/** hide menus **/
function hideMenus() {
	$(".menu").hide();
}

$(function () {
	$(document).click(hideMenus);
});
</script>

<h3><?php render_navigation($db); ?></h3>

<div class="operation">
	<?php render_db_menu($db) ?>
</div>
<style>
/* ===== Modern Table Style ===== */
table {
  width: 100%;
  border-collapse: collapse;
  margin: 1rem 0;
  background-color: #ffffff;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
  font-size: 13px;
}

th, td {
  padding: 10px 14px;
  text-align: left;
}

th {
  background-color: #f1f5f9;
  color: #1e293b;
  font-weight: 600;
  border-bottom: 2px solid #e2e2e2;
}

tr:nth-child(even) {
  background-color: #e2e2e2;  /* light grey row */
}

tr:nth-child(odd) {
  background-color: #ffffff;  /* white row */
}

tr:hover {
  background-color: #e0f2fe; /* subtle hover blue */
  transition: background-color 0.2s ease;
}

td {
  border-bottom: 1px solid #e2e2e2;
  color: #334155;
}

caption {
  caption-side: top;
  text-align: left;
  padding: 8px 0;
  font-weight: 600;
  color: #475569;
}

tfoot {
  background: #fafafa;
  font-weight: bold;
}
.action-footer {
  margin-top: 8px;
  font-family: "Segoe UI", Tahoma, sans-serif;
}
.action-footer select,
.action-footer button {
  padding: 4px 8px;
  font-size: 13px;
}

.clearfloat {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  gap: 1em;
  background: #f8f8f8;
  border: 1px solid #ddd;
  border-top: none;
  padding: 8px 12px;
  font-family: "Segoe UI", Tahoma, sans-serif;
  font-size: 14px;
  margin-top: 5px;
}

.clearfloat input[type="checkbox"] {
  cursor: pointer;
  width: 16px;
  height: 16px;
  accent-color: #007bff;
}

.clearfloat label {
  cursor: pointer;
  user-select: none;
}

.clearfloat select {
  font-size: 13px;
  padding: 3px 6px;
  border: 1px solid #ccc;
  border-radius: 3px;
  background-color: #fff;
  min-width: 180px;
}



.clearfloat optgroup {
  font-weight: bold;
  color: #555;
}

.clearfloat option {
  color: #333;
}
</style>



<form method="post" action="?action=db.multiAction&db=<?=$this->db;?>">
<table class="table-list">
  <thead>
    <tr>
      <th></th>
      <th>Collection</th>
      <th colspan="5">Action</th>
      <th>Rows</th>
      <th>Avg Object Size</th>
      <th>Data Size</th>
      <th>Storage Size</th>
      <th>Indexes</th>
      <th>Index Size</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($stats as $row): ?>
      <tr>
        <td><input type="checkbox" name="selected[]" value="<?php echo htmlspecialchars($row['sname']); ?>"></td>
        
           <td><?php echo $row['name']; ?></td>
       
        <td><?php echo $row['browse']; ?></td>
        
        <td><?php echo $row['search']; ?></td>
        <td><?php echo $row['insert']; ?></td>
        <td><?php echo $row['empty']; ?></td>
        <td><?php echo $row['drop']; ?></td>
        <td><?php echo $row['rows']; ?></td>
        <td><?php echo $row['avgObjSize']; ?></td>
        <td><?php echo $row['dataSize']; ?></td>
        <td><?php echo $row['storageSize']; ?></td>
        <td><?php echo $row['indexes']; ?></td>
        <td><?php echo $row['indexSize']; ?></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
  <tfoot>
    <tr>
      <td colspan="7"><?php echo $statsFooter['count']; ?> collections</td>
      <td><?php echo $statsFooter['rows']; ?></td>
      <td>-</td>
      <td><?php echo $statsFooter['dataSize']; ?></td>
      <td><?php echo $statsFooter['storageSize']; ?></td>
      <td>-</td>
      <td><?php echo $statsFooter['indexSize']; ?></td>
    </tr>
  </tfoot>
</table>

<div class="clearfloat d-print-none">

  <input type="checkbox" id="checkAll" title="Check all">
  <label for="checkAll" style="cursor:pointer;">Check all</label>

  <select name="submit_mult" style="margin: 0 3em 0 3em;">
    <option value="With selected:" selected="selected">With selected:</option>
    
    <option value="export">Export</option>
    <optgroup label="Delete data or collection">
      <option value="empty_tbl">Empty</option>
      <option value="drop_tbl">Drop</option>
    </optgroup>
    <optgroup label="Maintenance">
    
      <option value="repair_tbl">Repair</option>
    </optgroup>
  </select>

  <button type="submit">Go</button>
</div>



</form>

<script>
const checkAll = document.getElementById('checkAll');
checkAll.addEventListener('change', function() {
  const boxes = document.querySelectorAll('input[name="selected[]"]');
  boxes.forEach(b => b.checked = this.checked);
});

// Also toggle when label is clicked (for broader compatibility)
document.querySelector('label[for="checkAll"]').addEventListener('click', function(e) {
  e.preventDefault();
  checkAll.checked = !checkAll.checked;
  checkAll.dispatchEvent(new Event('change'));
});
</script>

