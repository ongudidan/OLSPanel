<?php exit("Permission Denied"); ?>
2025-10-18 14:22:47
array (
  'db' => 'admin',
  'collection' => 'Banglalink',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
    \'$set\' => array (
        //your attributes
    )
)',
  'field' => 
  array (
    0 => '$natural',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2025-10-18 14:22:51
array (
  'field' => 
  array (
    0 => 'undefined',
    1 => '$natural',
    2 => '',
    3 => '',
    4 => '',
  ),
  'order' => 
  array (
    0 => 'asc',
    1 => 'desc',
    2 => 'asc',
    3 => 'asc',
    4 => 'asc',
  ),
  'db' => 'admin',
  'collection' => 'Banglalink',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
    \'$set\' => array (
        //your attributes
    )
)',
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2025-10-18 14:23:44
array (
  'db' => 'admin',
  'collection' => 'Banglalink',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
    \'$set\' => array (
        //your attributes
    )
)',
  'field' => 
  array (
    0 => '$natural',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2025-10-18 14:36:22
array (
  'db' => 'admin',
  'collection' => 'Banglalink',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
    \'$set\' => array (
        //your attributes
    )
)',
  'field' => 
  array (
    0 => '$natural',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2025-10-18 14:37:22
array (
  'db' => 'admin',
  'collection' => 'Banglalink',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
    \'$set\' => array (
        //your attributes
    )
)',
  'field' => 
  array (
    0 => '$natural',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2025-10-18 14:48:04
array (
  'db' => 'admin',
  'collection' => 'Banglalink',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
    \'$set\' => array (
        //your attributes
    )
)',
  'field' => 
  array (
    0 => '$natural',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
