<?php exit("Permission Denied"); ?>
2025-10-17 04:43:02
array (
  'db' => 'myNewDB',
  'collection' => 'users',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
    \'$set\' => array (
        //your attributes
    )
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2025-10-17 04:43:10
array (
  'db' => 'myNewDB',
  'collection' => 'users',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
    \'$set\' => array (
        //your attributes
    )
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2025-10-17 05:47:17
array (
  'db' => 'myNewDB',
  'collection' => 'users',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
 \'detals\' => \'authSchema\',	
)',
  'newobj' => 'array(
    \'$set\' => array (
        //your attributes
    )
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
