<?php exit("Permission Denied"); ?>
2025-10-16 09:44:08
array (
  'db' => 'myNewDB',
  'collection' => 'recharge',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"id=>"ok"
}',
  'newobj' => '{
    \'$set\': {
        //your attributes
    }
}',
  'field' => 
  array (
    0 => '$natural',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2025-10-16 09:44:13
array (
  'db' => 'myNewDB',
  'collection' => 'recharge',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"id=>"ok"
}',
  'newobj' => '{
    \'$set\': {
        //your attributes
    }
}',
  'field' => 
  array (
    0 => '$natural',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2025-10-17 05:46:58
array (
  'db' => 'myNewDB',
  'collection' => 'recharge',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
    \'$set\' => array (
        //your attributes
    )
)',
  'field' => 
  array (
    0 => '$natural',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2025-10-19 08:55:42
array (
  'db' => 'myNewDB',
  'collection' => 'recharge',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
    \'$set\' => array (
        //your attributes
    )
)',
  'field' => 
  array (
    0 => '$natural',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
