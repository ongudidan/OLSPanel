<?php
class MDb {
    /**
     * Execute a piece of javascript code
     *
     * @param object $db DB object returned by RMongo::selectDB
     * @param string $code javascript code (ignored, only placeholder)
     * @param array $params javascript function parameters
     * @return array
     */
    static function exec($db, $code, array $params = []) {
        // Modern driver can't execute JS; just return empty
        return [];
    }

    /**
     * List collections in a DB
     *
     * @param object $db DB object returned by RMongo::selectDB
     * @return array of collection objects with getName() and count()
     */
   static function listCollections($db) {
    $server = MServer::currentServer();
    $collections = [];

    try {
        // Prefer the MongoDB extension’s listCollections command
        if (method_exists($db, 'listCollections')) {
            $cursor = $db->listCollections();
        } else {
            // Fallback for older driver versions
            $cursor = $db->command(['listCollections' => 1]);
        }

        foreach ($cursor as $collInfo) {
            // Support both object and array return types
            $name = $collInfo->name ?? ($collInfo->getName() ?? null);
            if (!$name) continue;

            // Apply RockMongo filters
            if ($server->shouldHideCollection($name)) continue;
            if (preg_match('/^system\./', $name) && $server->uiHideSystemCollections()) continue;

            $collections[] = new class($name, $db) {
                private string $name;
                private $db;

                public function __construct($name, $db) {
                    $this->name = $name;
                    $this->db = $db;
                }

                public function getName() {
                    return $this->name;
                }

                public function count() {
                    try {
                        $collection = $this->db->selectCollection($this->name);

                        // Handle both driver styles (old vs new)
                        if (method_exists($collection, 'countDocuments')) {
                            return $collection->countDocuments();
                        } elseif (method_exists($collection, 'count')) {
                            return $collection->count();
                        } else {
                            // fallback using command
                            $cmd = new MongoDB\Driver\Command([
                                'count' => $this->name
                            ]);
                            $cursor = $this->db->command($cmd);
                            $result = current($cursor->toArray());
                            return $result->n ?? 0;
                        }
                    } catch (Exception $e) {
                        error_log("[WARN] Count failed for {$this->name}: " . $e->getMessage());
                        return 0;
                    }
                }
               

                public function countDocuments(array $filter = []) {
                    try {
                        $cmd = new MongoDB\Driver\Command([
                            'count' => $this->name,
                            'query' => (object)$filter
                        ]);
                        $cursor = $this->manager->executeCommand($this->db, $cmd);
                        $res = current($cursor->toArray());
                        return isset($res->n) ? (int)$res->n : 0;
                    } catch (Exception $e) {
                        return 0;
                    }
                }
              public function find($filter = [], $options = []) {
                return ["ok" => 0, "errmsg" => "Use selectCollection('name')->find() instead of db->find()"];
            }
  
                
            };
        }
    } catch (Exception $e) {
        error_log("[ERROR] listCollections() failed: " . $e->getMessage());
        return [];
    }

    return $collections;
}


}
?>
