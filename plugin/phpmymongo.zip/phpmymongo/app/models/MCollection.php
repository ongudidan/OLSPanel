<?php

class MCollection {
    /**
     * Return all field names from the first document
     */
    public static function fields($db, $collection) {
        try {
            $cmd = [
                'find' => $collection,
                'limit' => 1
            ];
            $result = $db->command($cmd);
            if (!isset($result['cursor']['firstBatch'][0])) return [];
            $one = $result['cursor']['firstBatch'][0];
        } catch (Exception $e) {
            return [];
        }

        $fields = [];
        self::_fieldsFromRow($fields, $one);
        return $fields;
    }

    private static function _fieldsFromRow(&$fields, $row, $prefix = null) {
        foreach ($row as $field => $value) {
            if (is_int($field) || is_float($field)) continue;
            $namespace = $prefix ? "$prefix.$field" : $field;
            $fields[] = $namespace;
            if (is_array($value)) {
                self::_fieldsFromRow($fields, $value, $namespace);
            }
        }
    }

    /** Detect if a row is GridFS file metadata */
    public static function isFile(array $row) {
        return isset($row["filename"]) && isset($row["chunkSize"]);
    }

    /** Get .chunks collection name from .files */
    public static function chunksCollection($filesCollection) {
        return preg_replace("/\\.files$/", ".chunks", $filesCollection);
    }

    /** Collection info (stats) */
    public static function info($db, $collection) {
        $ret = $db->command(["collStats" => $collection]);
        if (!isset($ret["ok"]) || !$ret["ok"]) {
            exit("There is something wrong:<font color=\"red\">{$ret['errmsg']}</font>, please refresh the page to try again.");
        }

        $isCapped = $ret["capped"] ?? ($ret["options"]["capped"] ?? 0);
        $size     = $ret["maxSize"] ?? ($ret["options"]["size"] ?? 0);
        $max      = $ret["max"] ?? ($ret["options"]["max"] ?? 0);

        return [
            "capped" => $isCapped,
            "size"   => $size,
            "max"    => $max
        ];
    }

    /** ✅ Create collection — modern driver compatible */
    public static function createCollection($db, $name, array $options = []) {
        // New driver wrapper
        if (is_object($db) && method_exists($db, 'command')) {
            try {
                $cmd = ['create' => $name];

                if (!empty($options['capped'])) $cmd['capped'] = (bool)$options['capped'];
                if (!empty($options['size']))   $cmd['size']   = (int)$options['size'];
                if (!empty($options['max']))    $cmd['max']    = (int)$options['max'];

                $result = $db->command($cmd);
                if (isset($result['ok']) && $result['ok'] == 1) {
                    return true;
                } else {
                    throw new Exception($result['errmsg'] ?? 'Unknown error creating collection');
                }
            } catch (Exception $e) {
                throw new Exception("Create collection failed: " . $e->getMessage());
            }
        }

        // Legacy driver fallback
        if ($db instanceof MongoDB) {
            if (RMongo::compareVersion("1.4.0") >= 0) {
                $db->createCollection($name, $options);
            } else {
                $db->createCollection(
                    $name,
                    $options["capped"] ?? false,
                    $options["size"] ?? 0,
                    $options["max"] ?? 0
                );
            }
            return true;
        }

        throw new Exception("Invalid database object: expected MongoDB or wrapper");
    }
}

?>
