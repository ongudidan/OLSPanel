<?php
/**
 * RMongo PHP 8+ Compatibility Layer
 * Replaces old Mongo / MongoClient classes using MongoDB\Driver\Manager
 */
import("models.MUser"); 
class RMongo {
    private static $_lastId;
    private MongoDB\Driver\Manager $_mongo;
    private string $server;
private $authDb;
    private $username;
    private $password;
    
    /*
    public function __construct($server = "mongodb://127.0.0.1:27017", array $options = []) {
        if (!extension_loaded("mongodb")) {
            exit("MongoDB extension not installed. Please enable 'mongodb' in php.ini");
        }

        if (!preg_match('/^mongodb(\+srv)?:\/\//i', $server)) {
            $server = "mongodb://" . $server;
        }

        $this->server = $server;
        
        $user = MUser::userInSession();

        if ($user) {
            $this->username = $user->username();
            $this->authDb   = $user->defaultDb(); // or $user->dbs()[0]
        } else {
            $this->username = "guest";
            $this->authDb   = $authDb;
        }
        
        
        $this->_mongo = new MongoDB\Driver\Manager($server, $options);
    }
*/


public function __construct($server = "127.0.0.1:27017", array $options = []) {
      global $MONGO;
    
    
    if (!extension_loaded("mongodb")) {
        exit("MongoDB extension not installed. Please enable 'mongodb' in php.ini");
    }
 $i = 0; // default to first server
    if (isset($MONGO["servers"][$i])) {
        $serverInfo = $MONGO["servers"][$i];
        $host            = $serverInfo["mongo_host"] ?? "127.0.0.1";
        $port            = $serverInfo["mongo_port"] ?? 27017;
    }
    $server="{$host}:{$port}";   
    // --- normalize server string ---
    if (preg_match('/^mongodb(\+srv)?:\/\//i', $server)) {
        // remove prefix for clean rebuild
        $server = preg_replace('/^mongodb(\+srv)?:\/\//i', '', $server);
    }

    $user = MUser::userInSession();

    if ($user) {
        $this->username = $user->username();
        $this->password = $user->password();
        $this->authDb   = $user->defaultDb();
    } else {
        $this->username = "guest";
        $this->password = "";
        $this->authDb   = "admin";
    }

    // ✅ build clean MongoDB URI
    $uri = "mongodb://{$this->username}:{$this->password}@{$server}/?authSource={$this->authDb}";

    try {
        $this->_mongo = new MongoDB\Driver\Manager($uri, $options);
        $this->server = $uri;
    } catch (MongoDB\Driver\Exception\Exception $e) {
        exit("❌ MongoDB connection failed: " . $e->getMessage());
    }
}





 public function insert(string $db, string $collection, array $document) {
        try {
            $bulk = new MongoDB\Driver\BulkWrite;
            $bulk->insert($document);
            $namespace = "{$db}.{$collection}";
            $this->_mongo->executeBulkWrite($namespace, $bulk);
            return ["ok" => 1];
        } catch (MongoDB\Driver\Exception\Exception $e) {
            return ["ok" => 0, "errmsg" => $e->getMessage()];
        }
    }

    // ✅ Update documents
    public function update(string $db, string $collection, array $filter, array $update, array $options = []) {
        try {
            $bulk = new MongoDB\Driver\BulkWrite;
            $bulk->update($filter, $update, $options);
            $namespace = "{$db}.{$collection}";
            $this->_mongo->executeBulkWrite($namespace, $bulk);
            return ["ok" => 1];
        } catch (MongoDB\Driver\Exception\Exception $e) {
            return ["ok" => 0, "errmsg" => $e->getMessage()];
        }
    }

public function getManager() {
    if (isset($this->manager) && $this->manager instanceof MongoDB\Driver\Manager) {
        return $this->manager;
    }
    // If RMongo stores it in another variable name, adjust below
    if (isset($this->_manager) && $this->_manager instanceof MongoDB\Driver\Manager) {
        return $this->_manager;
    }
    throw new Exception("Mongo Manager not initialized in RMongo");
}



    public function __get($name) {
        if ($name === '_mongo') return $this;
    }

    public function close() {
        $this->_mongo = null;
        return true;
    }

    public function connect() {
        $command = new MongoDB\Driver\Command(["ping" => 1]);
        $this->_mongo->executeCommand($this->authDb, $command);
        return true;
    }

    public function dropDB($db) {
        $command = new MongoDB\Driver\Command(["dropDatabase" => 1]);
        $this->_mongo->executeCommand($db, $command);
        return true;
    }

    public function listDBs() {
        try {
            $command = new MongoDB\Driver\Command(["listDatabases" => 1]);
            $cursor = $this->_mongo->executeCommand($this->authDb, $command);
            $result = current($cursor->toArray());

            if (isset($result->databases)) {
                return [
                    "databases" => json_decode(json_encode($result->databases), true),
                    "ok" => 1
                ];
            } else {
                return [
                    "databases" => [],
                    "ok" => 0
                ];
            }
        } catch (Exception $e) {
            return [
                "databases" => [],
                "ok" => 0,
                "error" => $e->getMessage()
            ];
        }
    }

    public function selectDB($db) {
        $manager = $this->_mongo;

        return new class($manager, $db) {
            private MongoDB\Driver\Manager $manager;
            private string $db;

            public function __construct($manager, $db) {
                $this->manager = $manager;
                $this->db = $db;
            }

            // ✅ db->command([...])
            public function command(array $cmd) {
                try {
                    $command = new MongoDB\Driver\Command($cmd);
                    $cursor = $this->manager->executeCommand($this->db, $command);
                    $result = current($cursor->toArray());
                    return json_decode(json_encode($result), true);
                } catch (MongoDB\Driver\Exception\Exception $e) {
                    return ["ok" => 0, "errmsg" => $e->getMessage()];
                }
            }

            // ❌ JS eval removed
            public function execute(string $code, array $params = []) {
                return ["ok" => 0, "errmsg" => "execute() is not supported in MongoDB\Driver\Manager"];
            }

            // ✅ simulate success
            public function authenticate($user, $pass) {
                return ["ok" => 1];
            }

            // ✅ fallback if RockMongo calls $db->find()
            public function find($filter = [], $options = []) {
                return ["ok" => 0, "errmsg" => "Use selectCollection('name')->find() instead of db->find()"];
            }

            // ✅ db->createCollection(name, options)
            public function createCollection($name, array $options = []) {
                try {
                    $cmd = new MongoDB\Driver\Command([
                        'create' => $name
                    ] + $options);
                    $this->manager->executeCommand($this->db, $cmd);
                    return ["ok" => 1];
                } catch (MongoDB\Driver\Exception\Exception $e) {
                    return ["ok" => 0, "errmsg" => $e->getMessage()];
                }
            }

            // ✅ db->listCollections()
       public function listCollections() {
    try {
        $command = new MongoDB\Driver\Command(['listCollections' => 1]);
        $cursor = $this->manager->executeCommand($this->db, $command);

        $collections = [];
        foreach ($cursor as $coll) {
            $collArray = json_decode(json_encode($coll), true);
            $name = $collArray['name'] ?? null;
            if (!$name) continue;

            $collections[] = new class($this->manager, $this->db, $name) {
                private MongoDB\Driver\Manager $manager;
                private string $db;
                private string $name;

                public function __construct($manager, $db, $name) {
                    $this->manager = $manager;
                    $this->db = $db;
                    $this->name = $name;
                }

                public function getName() {
                    return $this->name;
                }

                public function count() {
                    return $this->countDocuments();
                }

                public function countDocuments(array $filter = []) {
                    try {
                        $cmd = new MongoDB\Driver\Command([
                            'count' => $this->name,
                            'query' => (object)$filter
                        ]);
                        $cursor = $this->manager->executeCommand($this->db, $cmd);
                        $res = current($cursor->toArray());
                        return isset($res->n) ? (int)$res->n : 0;
                    } catch (Exception $e) {
                        return 0;
                    }
                }

                public function find(array $filter = [], array $options = []) {
                    try {
                        $query = new MongoDB\Driver\Query($filter, $options);
                        $cursor = $this->manager->executeQuery("{$this->db}.{$this->name}", $query);
                        return iterator_to_array($cursor);
                    } catch (Exception $e) {
                        error_log("[ERROR] find() failed in {$this->db}.{$this->name}: " . $e->getMessage());
                        return [];
                    }
                }

                public function listIndexes() {
                    try {
                        $cmd = new MongoDB\Driver\Command(['listIndexes' => $this->name]);
                        $cursor = $this->manager->executeCommand($this->db, $cmd);
                        $indexes = [];
                        foreach ($cursor as $index) {
                            $indexes[] = json_decode(json_encode($index), true);
                        }
                        return $indexes;
                    } catch (Exception $e) {
                        error_log("[ERROR] listIndexes failed for {$this->db}.{$this->name}: " . $e->getMessage());
                        return [];
                    }
                }
            };
        }

        return $collections;
    } catch (Exception $e) {
        error_log("[ERROR] listCollections failed for {$this->db}: " . $e->getMessage());
        return [];
    }
}


  public function importx($inputDir) {
  // 🧩 Find BSON/JSON files in the main directory
$files = glob("$inputDir/*.{bson,json}", GLOB_BRACE);
//print_r($files);

// 🔍 If none found, search one level deeper (e.g., extracted zip with subfolder)
if (empty($files)) {
    $dirs = glob("$inputDir/*", GLOB_ONLYDIR); // find subfolders
    foreach ($dirs as $d) {
        echo "Checking subdir: $d<br/>";
        $subFiles = glob("$d/*.{bson,json}", GLOB_BRACE);
        if (!empty($subFiles)) {
            $files = $subFiles; // use files found inside subdir
            $inputDir = $d; // update input dir
            break;
        }
    }
}

//print_r($files);


    $imported = [];

    if (empty($files)) {
        echo "No importable BSON/JSON files found<br/>";
        return;
    }

    foreach ($files as $file) {
        if (preg_match('/\.metadata\.json$/', $file)) continue; // skip metadata

        $collection = basename($file, strrchr($file, '.'));
        
        $bulk = new MongoDB\Driver\BulkWrite();
        $count = 0;

        // --- BSON IMPORT ---
       if (preg_match('/\.bson$/', $file)) {
    $f = fopen($file, "rb");
    if (!$f) {
        echo "❌ Failed to open $collection<br/>";
        continue;
    }

    while (!feof($f)) {
    // Read 4 bytes: total length of BSON document
    $lenData = fread($f, 4);
    if (strlen($lenData) < 4) break;

    $len = unpack('V', $lenData)[1];
    if ($len <= 0 || $len > 100000000) { // sanity check
        echo "⚠️ Invalid BSON length $len in $collection<br/>";
        break;
    }

    // Read rest of the BSON document
    $docBson = $lenData . fread($f, $len - 4);
    if (strlen($docBson) != $len) {
        echo "⚠️ Incomplete BSON document at offset " . ftell($f) . "<br/>";
        break;
    }

    try {
        // ✅ PHP 8.1-compatible BSON decoding
        $doc = MongoDB\BSON\Document::fromBSON($docBson)->toPHP();
        $bulk->insert($doc);
        $count++;
    } catch (Exception $e) {
        echo "⚠️ BSON decode error: " . $e->getMessage() . "<br/>";
        continue;
    }
}


    fclose($f);
   
}


        // --- JSON IMPORT ---
        elseif (preg_match('/\.json$/', $file)) {
            $json = json_decode(file_get_contents($file), true);
            if (!$json) continue;
            foreach ($json as $doc) {
                if (is_array($doc)) {
                    $bulk->insert($doc);
                    $count++;
                }
            }
        }

        // --- Commit inserts ---
        if ($count > 0) {
            try {
                $this->manager->executeBulkWrite("{$this->db}.{$collection}", $bulk);
                $imported[] = "$collection ($count)";
               echo "✅ Imported $collection ($count docs)<br/>";
            } catch (Exception $e) {
                echo "❌ Failed to import $collection: " . $e->getMessage() . "<br/>";
            }
        }
    }

    // --- Summary ---
    if ($imported)
      echo "✅ All imported collections: " . implode(", ", $imported) . "<br/>";
    else
        echo "⚠️ No valid documents found to import in <br/>";
}

public function import($inputDir) {
    $logs = [];

    // 🧩 Find BSON/JSON files in the main directory
    $files = glob("$inputDir/*.{bson,json}", GLOB_BRACE);

    // 🔍 If none found, search one level deeper (e.g., extracted zip with subfolder)
    if (empty($files)) {
        $dirs = glob("$inputDir/*", GLOB_ONLYDIR);
        foreach ($dirs as $d) {
            $logs[] = "Checking subdir: $d";
            $subFiles = glob("$d/*.{bson,json}", GLOB_BRACE);
            if (!empty($subFiles)) {
                $files = $subFiles;
                $inputDir = $d;
                break;
            }
        }
    }

    $imported = [];

    if (empty($files)) {
        $logs[] = "⚠️ No importable BSON/JSON files found.";
        return implode("\n", $logs);
    }

    foreach ($files as $file) {
        if (preg_match('/\.metadata\.json$/', $file)) continue; // skip metadata

        $collection = basename($file, strrchr($file, '.'));
        $bulk = new MongoDB\Driver\BulkWrite();
        $count = 0;

        // --- BSON IMPORT ---
        if (preg_match('/\.bson$/', $file)) {
            $f = fopen($file, "rb");
            if (!$f) {
                $logs[] = "❌ Failed to open $collection.";
                continue;
            }

            while (!feof($f)) {
                $lenData = fread($f, 4);
                if (strlen($lenData) < 4) break;

                $len = unpack('V', $lenData)[1];
                if ($len <= 0 || $len > 100000000) {
                    $logs[] = "⚠️ Invalid BSON length $len in $collection.";
                    break;
                }

                $docBson = $lenData . fread($f, $len - 4);
                if (strlen($docBson) != $len) {
                    $logs[] = "⚠️ Incomplete BSON document at offset " . ftell($f) . " in $collection.";
                    break;
                }

                try {
                    $doc = MongoDB\BSON\Document::fromBSON($docBson)->toPHP();
                    $bulk->insert($doc);
                    $count++;
                } catch (Exception $e) {
                    $logs[] = "⚠️ BSON decode error in $collection: " . $e->getMessage();
                    continue;
                }
            }

            fclose($f);
        }

        // --- JSON IMPORT ---
        elseif (preg_match('/\.json$/', $file)) {
            $json = json_decode(file_get_contents($file), true);
            if (!$json) {
                $logs[] = "⚠️ Invalid JSON in $collection.";
                continue;
            }
            foreach ($json as $doc) {
                if (is_array($doc)) {
                    $bulk->insert($doc);
                    $count++;
                }
            }
        }

        // --- Commit inserts ---
        if ($count > 0) {
            try {
                $this->manager->executeBulkWrite("{$this->db}.{$collection}", $bulk);
                $imported[] = "$collection ($count)";
                $logs[] = "✅ Imported $collection ($count docs).";
            } catch (Exception $e) {
                $logs[] = "❌ Failed to import $collection: " . $e->getMessage();
            }
        }
    }

    // --- Summary ---
    if ($imported) {
        $logs[] = "✅ All imported collections: " . implode(", ", $imported);
    } else {
        $logs[] = "⚠️ No valid documents found to import.";
    }

    // ✅ Return combined log text
    return implode("\n", $logs);
}



            // ✅ selectCollection()
            public function selectCollection($collectionName) {
                $manager = $this->manager;
                $db = $this->db;
                $collection = $collectionName;

                return new class($manager, $db, $collection) {
                    private MongoDB\Driver\Manager $manager;
                    private string $db;
                    private string $collection;

                    public function __construct($manager, $db, $collection) {
                        $this->manager = $manager;
                        $this->db = $db;
                        $this->collection = $collection;
                    }

                    public function find(array $filter = [], array $options = []) {
                        $query = new MongoDB\Driver\Query($filter, $options);
                        $namespace = "{$this->db}.{$this->collection}";
                        try {
                            $cursor = $this->manager->executeQuery($namespace, $query);
                            $docs = [];
                            foreach ($cursor as $doc) {
                                $docs[] = json_decode(json_encode($doc), true);
                            }
                            return $docs;
                        } catch (MongoDB\Driver\Exception\Exception $e) {
                            return [];
                        }
                    }

                    public function findOne(array $filter = [], array $options = []) {
                        $options['limit'] = 1;
                        $result = $this->find($filter, $options);
                        return $result[0] ?? null;
                    }

                    public function count(array $filter = []) {
                        try {
                            $cmd = new MongoDB\Driver\Command([
                                'count' => $this->collection,
                                'query' => (object)$filter
                            ]);
                            $cursor = $this->manager->executeCommand($this->db, $cmd);
                            $result = current($cursor->toArray());
                            return isset($result->n) ? (int)$result->n : 0;
                        } catch (MongoDB\Driver\Exception\Exception $e) {
                            return 0;
                        }
                    }
 public function countDocuments(array $filter = []) {
    return $this->count($filter);
}
                    public function insert(array $document) {
                        try {
                            $bulk = new MongoDB\Driver\BulkWrite;
                            $bulk->insert($document);
                            $namespace = "{$this->db}.{$this->collection}";
                            $this->manager->executeBulkWrite($namespace, $bulk);
                            return ["ok" => 1];
                        } catch (MongoDB\Driver\Exception\Exception $e) {
                            return ["ok" => 0, "errmsg" => $e->getMessage()];
                        }
                    }

                    public function update(array $filter, array $newData, array $options = []) {
                        try {
                            $bulk = new MongoDB\Driver\BulkWrite;
                            $bulk->update(
                                $filter,
                                ['$set' => $newData],
                                ['multi' => $options['multi'] ?? false, 'upsert' => $options['upsert'] ?? false]
                            );
                            $namespace = "{$this->db}.{$this->collection}";
                            $this->manager->executeBulkWrite($namespace, $bulk);
                            return ["ok" => 1];
                        } catch (MongoDB\Driver\Exception\Exception $e) {
                            return ["ok" => 0, "errmsg" => $e->getMessage()];
                        }
                    }

                    public function remove(array $filter, array $options = []) {
                        try {
                            $bulk = new MongoDB\Driver\BulkWrite;
                            $bulk->delete($filter, ['limit' => $options['justOne'] ?? false]);
                            $namespace = "{$this->db}.{$this->collection}";
                            $this->manager->executeBulkWrite($namespace, $bulk);
                            return ["ok" => 1];
                        } catch (MongoDB\Driver\Exception\Exception $e) {
                            return ["ok" => 0, "errmsg" => $e->getMessage()];
                        }
                    }

                    public function getIndexInfo() {
                        try {
                            $cmd = new MongoDB\Driver\Command(['listIndexes' => $this->collection]);
                            $cursor = $this->manager->executeCommand($this->db, $cmd);
                            $indexes = [];
                            foreach ($cursor as $index) {
                                $indexes[] = json_decode(json_encode($index), true);
                            }
                            return $indexes;
                        } catch (MongoDB\Driver\Exception\Exception $e) {
                            return [];
                        }
                    }

                    public function ensureIndex(array $keys, array $options = []) {
                        try {
                            $cmd = new MongoDB\Driver\Command([
                                'createIndexes' => $this->collection,
                                'indexes' => [[
                                    'key' => $keys,
                                    'name' => implode('_', array_keys($keys)) . '_idx'
                                ] + $options]
                            ]);
                            $this->manager->executeCommand($this->db, $cmd);
                            return ["ok" => 1];
                        } catch (MongoDB\Driver\Exception\Exception $e) {
                            return ["ok" => 0, "errmsg" => $e->getMessage()];
                        }
                    }
                    
                    
                    // ✅ Alias for RockMongo compatibility
public function listIndexes() {
    try {
        $cmd = new MongoDB\Driver\Command(['listIndexes' => $this->collection]);
        $cursor = $this->manager->executeCommand($this->db, $cmd);

        $indexes = [];
        foreach ($cursor as $indexInfo) {
            $infoArray = json_decode(json_encode($indexInfo), true);

            // Create RockMongo-compatible wrapper
            $indexes[] = new class($infoArray) {
                private array $info;

                public function __construct(array $info) {
                    $this->info = $info;
                }

                public function getKey() {
                    return $this->info['key'] ?? [];
                }

                public function getName() {
                    return $this->info['name'] ?? '';
                }

                public function isUnique() {
                    return !empty($this->info['unique']);
                }

                public function getInfo() {
                    return $this->info;
                }
            };
        }

        // Return something iterable (RockMongo expects Traversable)
        return new ArrayIterator($indexes);
    } catch (MongoDB\Driver\Exception\Exception $e) {
        error_log("[ERROR] listIndexes failed for {$this->db}.{$this->collection}: " . $e->getMessage());
        return new ArrayIterator([]);
    }
}


  public function export($outputDir, $zip = false, $gz = false) {
            if (!is_dir($outputDir)) mkdir($outputDir, 0777, true);

            $namespace = "{$this->db}.{$this->collection}";
            $query = new MongoDB\Driver\Query([]);
            $cursor = $this->manager->executeQuery($namespace, $query);

            $bsonFile = "$outputDir/{$this->collection}.bson";
            $metaFile = "$outputDir/{$this->collection}.metadata.json";

            $f = fopen($bsonFile, "wb");
            $count = 0;
            foreach ($cursor as $doc) {
                $count++;
                //$bson  = MongoDB\BSON\Document::fromPHP($doc)->toRelaxedExtendedJSON();
                $document = MongoDB\BSON\Document::fromPHP($doc);
        $bson = (string)$document;
                fwrite($f, $bson);
            }
            fclose($f);

            file_put_contents($metaFile, json_encode([
                "name" => $this->collection,
                "count" => $count,
                "timestamp" => date("Y-m-d H:i:s")
            ], JSON_PRETTY_PRINT));

            

            

            echo "✅ Exported {$this->collection} ({$count} docs)\n";
        }



    // Convert PHP → BSON safely
    private function safeToBson($data) {
        if (function_exists('MongoDB\BSON\fromPHP')) {
            return MongoDB\BSON\fromPHP($data);
        } elseif (function_exists('bson_encode')) {
            return bson_encode($data);
        } else {
            // fallback JSON → BSON (inefficient but safe)
            return MongoDB\BSON\fromJSON(json_encode($data));
        }
    }
                    
                };
            }
        };
    }

    public function selectCollection($db, $collection) {
        $manager = $this->_mongo;
        return new class($manager, $db, $collection) {
            private MongoDB\Driver\Manager $manager;
            private string $db;
            private string $collection;
            public function __construct($manager, $db, $collection) {
                $this->manager = $manager;
                $this->db = $db;
                $this->collection = $collection;
            }
        };
    }

    public static function getVersion() {
        return phpversion("mongodb");
    }

    public static function compareVersion($version) {
        return version_compare(phpversion("mongodb"), $version);
    }

    public static function setLastInsertId($lastId) {
        self::$_lastId = $lastId;
    }

    public static function lastInsertId() {
        return self::$_lastId;
    }

    public function __toString() {
        return "RMongo connection to {$this->server}";
    }
    
    public function selectDatabase($db) {
    return $this->selectDB($db);
}


public function command_run($cmd, $dbName = null) {
    $manager = null;

    if (property_exists($this, '_mongo')) {
        $ref = new ReflectionClass($this);
        if ($ref->hasProperty('_mongo')) {
            $prop = $ref->getProperty('_mongo');
            $prop->setAccessible(true);
            $manager = $prop->getValue($this);
        }
    }

    if (!$manager instanceof MongoDB\Driver\Manager) {
        throw new Exception("MongoDB Manager not found inside RMongo instance");
    }

    // Default to current DB if not specified
    $db = $dbName ?: $this->db;

    $command = new MongoDB\Driver\Command($cmd);
    return $manager->executeCommand($db, $command);
}

    /**
     * Authenticate and connect to MongoDB
     * Compatible with old RockMongo-style auth flow
     */
   public function login(string $username = "", string $password = "", string $db = "admin"): array
{
    if (!extension_loaded("mongodb")) {
        return ["ok" => 0, "errmsg" => "MongoDB extension not installed"];
    }

    try {
        // Build connection string using same host but with credentials
        $uri = $this->server;

        // Add credentials if provided
        if ($username && $password) {
            // Parse existing host
            $parts = parse_url($uri);
            $auth = urlencode($username) . ":" . urlencode($password) . "@";
            $host = $parts['host'] ?? "127.0.0.1";
            $port = $parts['port'] ?? 27017;
            $uri = "mongodb://{$auth}{$host}:{$port}/{$db}";
        }

        // Try re-connecting with authentication
        $this->_mongo = new MongoDB\Driver\Manager($uri);

        // Verify authentication
        $command = new MongoDB\Driver\Command(["ping" => 1]);
        $this->_mongo->executeCommand($db, $command);

        return ["ok" => 1, "message" => "Login successful"];
    } catch (MongoDB\Driver\Exception\AuthenticationException $e) {
        return ["ok" => 0, "errmsg" => "Authentication failed: " . $e->getMessage()];
    } catch (Exception $e) {
        return ["ok" => 0, "errmsg" => $e->getMessage()];
    }
}





}
?>
