<?php
use MongoDB\Client;
use MongoDB\BSON\ObjectId;

class RQuery
{
    private $_db;
    private $_collection;
    private $_attrs = [];    // field conditions
    private $_sort = [];     // sorting
    private $_limit = 0;
    private $_offset = 0;
    private $_projection = [];
    private $_noPk = false;

    public function __construct(Client $mongo, $dbName, $collectionName)
    {
        $this->_db = $mongo->selectDatabase($dbName);
        $this->_collection = $this->_db->selectCollection($collectionName);
    }

    public function cond(array $cond)
    {
        foreach ($cond as $key => $value) {
            if ($key === "_id" && !($value instanceof ObjectId)) {
                $value = new ObjectId($value);
            }
            $this->_attrs[$key] = $value;
        }
        return $this;
    }

    public function attr($field, $value)
    {
        return $this->cond([$field => $value]);
    }

    public function limit($limit)
    {
        $this->_limit = intval($limit);
        return $this;
    }

    public function offset($offset)
    {
        $this->_offset = intval($offset);
        return $this;
    }

    public function result($fields)
    {
        foreach ((array)$fields as $field) {
            $this->_projection[$field] = 1;
        }
        return $this;
    }

    public function exclude($fields)
    {
        foreach ((array)$fields as $field) {
            $this->_projection[$field] = 0;
        }
        return $this;
    }

    public function asc($field)
    {
        $this->_sort[$field] = 1;
        return $this;
    }

    public function desc($field)
    {
        $this->_sort[$field] = -1;
        return $this;
    }

    public function noPk($noPk = true)
    {
        $this->_noPk = $noPk;
        return $this;
    }

    // Find all documents matching criteria
    public function findAll($keepId = true)
    {
        $options = [
            'limit' => $this->_limit > 0 ? $this->_limit : 0,
            'skip' => $this->_offset,
            'sort' => $this->_sort,
            'projection' => $this->_projection
        ];

        $cursor = $this->_collection->find($this->_attrs, $options);
        $results = iterator_to_array($cursor);

        if ($this->_noPk) {
            foreach ($results as &$r) {
                unset($r['_id']);
            }
        } elseif (!$keepId) {
            foreach ($results as &$r) {
                if (isset($r['_id']) && $r['_id'] instanceof ObjectId) {
                    $r['_id'] = (string)$r['_id'];
                }
            }
        }

        return $results;
    }

    public function findOne($id = null)
    {
        if ($id !== null) {
            $this->cond(['_id' => new ObjectId($id)]);
        }
        $options = ['limit' => 1, 'projection' => $this->_projection];
        $result = $this->_collection->findOne($this->_attrs, $options);

        if ($result && !$this->_noPk && isset($result['_id']) && $result['_id'] instanceof ObjectId) {
            $result['_id'] = (string)$result['_id'];
        }

        if ($result && $this->_noPk) {
            unset($result['_id']);
        }

        return $result ? (array)$result : [];
    }

    public function insert(array $data)
    {
        if (!isset($data['_id'])) {
            $data['_id'] = new ObjectId();
        }
        $result = $this->_collection->insertOne($data);
        return $result->getInsertedId();
    }

    public function update(array $data, $upsert = false, $multiple = true)
    {
        $options = ['upsert' => $upsert];
        if ($multiple) {
            $result = $this->_collection->updateMany($this->_attrs, ['$set' => $data], $options);
        } else {
            $result = $this->_collection->updateOne($this->_attrs, ['$set' => $data], $options);
        }
        return $result->getModifiedCount();
    }

    public function delete($multiple = true)
    {
        if ($multiple) {
            $result = $this->_collection->deleteMany($this->_attrs);
        } else {
            $result = $this->_collection->deleteOne($this->_attrs);
        }
        return $result->getDeletedCount();
    }

    public function count()
    {
        return $this->_collection->countDocuments($this->_attrs);
    }

    public function collection()
    {
        return $this->_collection;
    }

    public function db()
    {
        return $this->_db;
    }
}
