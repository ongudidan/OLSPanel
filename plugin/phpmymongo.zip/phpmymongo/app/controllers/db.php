<?php

import("classes.BaseController");

class DbController extends BaseController {
	/** database **/
	/*
	public function doIndex() {
		$this->db = trim(xn("db"));

		$dbs = $this->_server->listDbs();
		$ret = array();
		foreach ($dbs["databases"] as $db) {
			if ($db["name"] == $this->db) {
				$ret = $db;
			}
		}

		//collections
		$db = $this->_mongo->selectDB($this->db);
		$collections = MDb::listCollections($db);

		$ret = array_merge($ret, $db->command(array("dbstats" => 1)));
		$ret["diskSize"] = "-";
		if (isset($ret["sizeOnDisk"])) {
			$ret["diskSize"] = r_human_bytes($ret["sizeOnDisk"]);
		}
		if(isset($ret["dataSize"])) {
			$ret["dataSize"] = r_human_bytes($ret["dataSize"]);
		}
		if(isset($ret["storageSize"])) {
			$ret["storageSize"] = r_human_bytes($ret["storageSize"]);
		}
		if(isset($ret["indexSize"])) {
			$ret["indexSize"] = r_human_bytes($ret["indexSize"]);
		}


		$this->stats = array();
		$this->stats["Size"] = $ret["diskSize"];
		$this->stats["Is Empty?"] = $ret["empty"] ? "Yes" : "No";
		if (empty($collections)) {
			$this->stats["Collections"] = count($collections) . " collections:";
			$this->stats["Collections"] .= "<br/>No collections yet";
		}
		else {
			$key = "Collections<br/>[<a href=\"" . $this->path("db.dropDbCollections", array( "db" => $this->db )) . "\" onclick=\"return window.confirm('Are you sure to drop all collections in the db?')\"><u>Drop All</u></a>]<br/>[<a href=\"" . $this->path("clearDbCollections", array( "db" => $this->db )) . "\" onclick=\"return window.confirm('Are you sure to clear all records in all collections?')\"><u>Clear All</u></a>]";
			$this->stats[$key] = count($collections) . " collections:";
			foreach ($collections as $collection) {
				$this->stats[$key] .= "<br/><a href=\""
					. $this->path("collection.index", array( "db" => $this->db, "collection" => $collection->getName())) . "\">" . $collection->getName() . "</a>";
			}
		}
		if(isset($ret["objects"])) {
			$this->stats["Objects"] = $ret["objects"];
		}
		if (isset($ret["avgObjSize"])) {
			$this->stats["Avg Object Size"] = r_human_bytes($ret["avgObjSize"]);
		}
		if(isset($ret["dataSize"])) {
			$this->stats["Data Size"] = $ret["dataSize"];
		}
		if(isset($ret["storageSize"])) {
			$this->stats["Storage Size"] = $ret["storageSize"];
		}
		if(isset($ret["numExtents"])) {
			$this->stats["Extents"] = $ret["numExtents"];
		}
		if(isset($ret["indexes"])) {
			$this->stats["Indexes"] = $ret["indexes"];
		}
		if(isset($ret["indexSize"])) {
			$this->stats["Index Size"] = r_human_bytes($ret["indexSize"]);
		}
		if (isset($ret["fileSize"])) {
			$this->stats["Total File Size"] = r_human_bytes($ret["fileSize"]);
		}
		if (isset($ret["nsSizeMB"])) {
			$this->stats["Namespace Size"] = $ret["nsSizeMB"] . "m";
		}
		if (isset($ret["dataFileVersion"])) {
			$this->stats["Data File Version"] = $this->_highlight($ret["dataFileVersion"], "json");
		}
		if (isset($ret["extentFreeList"])) {
			$this->stats["Extent Free List"] = $this->_highlight($ret["extentFreeList"], "json");
		}

		$this->display();
	}
*/

public function doIndex() {
    $this->db = trim(xn("db"));
    $db = $this->_mongo->selectDB($this->db);
    $collections = MDb::listCollections($db);

    $this->stats = [];
    $totalRows = 0;
    $totalDataSize = 0;
    $totalStorageSize = 0;
    $totalIndexSize = 0;

    foreach ($collections as $collection) {
        $name = $collection->getName();
        $collStats = $db->command(["collStats" => $name]);

        $rows = isset($collStats["count"]) ? $collStats["count"] : 0;
        $avgObj = isset($collStats["avgObjSize"]) ? r_human_bytes($collStats["avgObjSize"]) : "-";
        $dataSize = isset($collStats["size"]) ? r_human_bytes($collStats["size"]) : "-";
        $storageSize = isset($collStats["storageSize"]) ? r_human_bytes($collStats["storageSize"]) : "-";
        $indexes = isset($collStats["nindexes"]) ? $collStats["nindexes"] : "-";
        $indexSize = isset($collStats["totalIndexSize"]) ? r_human_bytes($collStats["totalIndexSize"]) : "-";

        $totalRows += $rows;
        $totalDataSize += $collStats["size"] ?? 0;
        $totalStorageSize += $collStats["storageSize"] ?? 0;
        $totalIndexSize += $collStats["totalIndexSize"] ?? 0;

        $browseUrl = $this->path("collection.index", ["db" => $this->db, "collection" => $name]);
        $structureUrl = $this->path("collection.structure", ["db" => $this->db, "collection" => $name]);
        $searchUrl = $this->path("collection.search", ["db" => $this->db, "collection" => $name]);
        $insertUrl = $this->path("collection.createRow", ["db" => $this->db, "collection" => $name]);
        $emptyUrl = $this->path("collection.clearRows", ["db" => $this->db, "collection" => $name]);
        $dropUrl = $this->path("collection.removeCollection", ["db" => $this->db, "collection" => $name]);

        $this->stats[] = [
            "sname" => $name,
            "name" => "<a href='$browseUrl'><b>".htmlspecialchars($name)."</b></a>",
            "browse" => "<a href='$browseUrl'>Browse</a>",
            "structure" => "<a href='$structureUrl'>Structure</a>",
            "search" => "<a href='$browseUrl'>Search</a>",
            "insert" => "<a href='$insertUrl'>Insert</a>",
            "empty" => "<a href='$emptyUrl' onclick='return confirm(\"Empty collection $name?\")'>Empty</a>",
            "drop" => "<a href='$dropUrl' onclick='return confirm(\"Drop collection $name?\")'>Drop</a>",
            "rows" => $rows,
            "avgObjSize" => $avgObj,
            "dataSize" => $dataSize,
            "storageSize" => $storageSize,
            "indexes" => $indexes,
            "indexSize" => $indexSize,
        ];
    }

    $this->statsFooter = [
        "count" => count($collections),
        "rows" => $totalRows,
        "dataSize" => r_human_bytes($totalDataSize),
        "storageSize" => r_human_bytes($totalStorageSize),
        "indexSize" => r_human_bytes($totalIndexSize),
    ];

    $this->display();
}

public function doMultiAction() {
    $this->db = x("db");
    $saction = xn("submit_mult");
    $collections = $_POST['selected'] ?? [];

    if (empty($collections)) {
        $this->error = "No collections selected.";
        $this->display();
        return;
    }

    try {
        $db = $this->_mongo->selectDB($this->db);
        $results = [];

        foreach ($collections as $collectionName) {
            switch ($saction) {
                case "drop_tbl":
                    $result = $db->command(['drop' => $collectionName]);
                    $results[$collectionName] = $result['ok'] ? "Dropped" : "Failed to drop";
                    break;

                case "empty_tbl":
                    $coll = $db->selectCollection($collectionName);
                    $coll->remove([], ['justOne' => false]);
                    $results[$collectionName] = "Cleared";
                    break;

                case "export":
                import("classes.VarExportor");
                $contents = "";
                $countRows = 0;

  $baseDir = __DIR__ . "/../tmp/dbexports";
    if (!is_dir($baseDir)) {
        mkdir($baseDir, 0755, true);
    }

    $outputDir = "$baseDir/{$this->db}";
    if (!is_dir($outputDir)) {
        mkdir($outputDir, 0755, true);
    }

    // ✅ Select database
  

        // ✅ Export each collection
       foreach ($collections as $collection) {
            $coll = $db->selectCollection($collection);
            // call your RMongoCollection export method
            $coll->export($outputDir, false);
        }

        // ✅ Handle compression (zip or gz)
      

 $zipPath = "$baseDir/{$this->db}.zip";

// Create ZIP using system command (fast & reliable)
$cmd = "cd " . escapeshellarg($outputDir) . " && zip -r " . escapeshellarg($zipPath) . " .";
system($cmd, $returnCode);

if ($returnCode === 0 && file_exists($zipPath)) {
    header("Content-Type: application/zip");
    header("Content-Disposition: attachment; filename=\"{$this->db}.zip\"");
    header("Content-Length: " . filesize($zipPath));
    readfile($zipPath);

    // Cleanup
    unlink($zipPath);
    $this->rrmdir($outputDir);
    exit;
} else {
    error_log("Failed to create zip file. Return code: $returnCode");
}

 
 
                case "repair_tbl":
                    	$db = $this->_mongo->selectDB($this->db);
		                $ret = $db->command(array( "repairDatabase" => 1 ));
		                $this->ret = $this->_highlight($ret, "json");
                default:
                    $results[$collectionName] = "Unknown action";
            }
        }

echo '<script>
                window.parent.frames["left"].location.reload();
                window.location.href = "' . url("db.index", ["db" => $this->db]) . '";
              </script>';
        // ✅ Reload sidebar and show result
       	$this->redirect("db.index", array(
			"db" => $this->db
		));

    } catch (Exception $e) {
        $this->error = "Multi-action failed: " . $e->getMessage();
        $this->display();
    }
}


	/** transfer db collections from one server to another **/
	public function doDbTransfer() {
		$this->db = xn("db");

		$db = $this->_mongo->selectDB($this->db);
		$this->collections = $db->listCollections();
		$this->servers = $this->_admin->servers();

		$this->selectedCollections = array();
		if (!$this->isPost()) {
			$this->selectedCollections[] = xn("collection");
			x("copy_indexes", 1);
			$this->target_host = "";
			$this->target_sock = "";
			$this->target_port = 27017;
			$this->target_auth = 0;
			$this->target_username = "";
			$this->target_password = "";
		}
		else {
			$this->target_host = trim(xn("target_host"));
			$this->target_sock = trim(xn("target_sock"));
			$this->target_port = xi("target_port");
			$this->target_auth = xi("target_auth");
			$this->target_username = trim(xn("target_username"));
			$this->target_password = trim(xn("target_password"));

			$checkeds = xn("checked");
			if (is_array($checkeds)) {
				$this->selectedCollections = array_keys($checkeds);
			}
			if (empty($checkeds)) {
				$this->error = "Please select collections which you want to transfer.";
				$this->display();
				return;
			}
			if (empty($this->target_host) && empty($this->target_sock)) {
				$this->error = "Target host must not be empty.";
				$this->display();
				return;
			}
			$copyIndexes = xi("copy_indexes");
			/**if ($target === "") {
				$this->error = "Please enter a valid database name.";
				$this->display();
				return;
			}**/

			//start to transfer
			$targetOptions = array();
			if ($this->target_auth) {
				$targetOptions["username"] = $this->target_username;
				$targetOptions["password"] = $this->target_password;
			}
			$uri = null;
			if ($this->target_sock) {
				$uri = "mongodb://" . $this->target_sock;
			}
			else {
				$uri = "mongodb://" . $this->target_host . ":" . $this->target_port;
			}
			$targetConnection = new RMongo($uri, $targetOptions);
			$targetDb = $targetConnection->selectDB($this->db);
			if ($this->target_auth) {
				// "authenticate" can only be used between 1.0.1 - 1.2.11
				if (RMongo::compareVersion("1.0.1") >= 0 && RMongo::compareVersion("1.2.11") < 0) {
					$targetDb->authenticate($this->target_username, $this->target_password);
				}
			}
			$errors = array();
			foreach ($this->selectedCollections as $collectionName) {
				$ret = $targetDb->command(array(
					"cloneCollection" => $this->db . "." . $collectionName,
					"from" =>  $this->_server->uri(),
					"copyIndexes" => (bool)$copyIndexes
				));
				if (!$ret["ok"]) {
					$errors[] = MMongo::readException($ret);
					break;
				}
			}
			if (!empty($errors)) {
				$this->error = implode("<br/>", $errors);
				$this->display();
				return;
			}

			$this->message = "All data were transfered to '{$this->target_host}' successfully.";
		}

		$this->display();
	}

	/** export db **/

	public function doDbExportxx() {
		$this->db = xn("db");

		$db = $this->_mongo->selectDB($this->db);
		$this->collections = MDb::listCollections($db);
		$this->selectedCollections = array();
		if (!$this->isPost()) {
			$this->selectedCollections[] = xn("collection");
		}
		else {
			$checkeds = xn("checked");
			$canDownload = xn("can_download");
			if (is_array($checkeds)) {
				$this->selectedCollections = array_keys($checkeds);
			}

			sort($this->selectedCollections);

			import("classes.VarExportor");
			$this->contents =  "";
			$this->countRows = 0;

			//indexes
			foreach ($this->selectedCollections as $collection) {
				$collObj = $db->selectCollection($collection);
				$infos = $collObj->getIndexInfo();
				foreach ($infos as $info) {
					$options = array();
					if (isset($info["unique"])) {
						$options["unique"] = $info["unique"];
					}
					$exportor = new VarExportor($db, $info["key"]);
					$exportor2 = new VarExportor($db, $options);
					$this->contents .= "\n/** {$collection} indexes **/\ndb.getCollection(\"" . addslashes($collection) . "\").ensureIndex(" . $exportor->export(MONGO_EXPORT_JSON) . "," . $exportor2->export(MONGO_EXPORT_JSON) . ");\n";
				}
			}

			//data
			foreach ($this->selectedCollections as $collection) {
				$cursor = $db->selectCollection($collection)->find();
				$this->contents .= "\n/** " . $collection  . " records **/\n";
				foreach ($cursor as $one) {
					$this->countRows ++;
					$exportor = new VarExportor($db, $one);
					$this->contents .= "db.getCollection(\"" . addslashes($collection) . "\").insert(" . $exportor->export(MONGO_EXPORT_JSON) . ");\n";
					unset($exportor);
				}
				unset($cursor);
			}
			if (x("can_download")) {
				$prefix = "mongo-" . urlencode($this->db) . "-" . date("Ymd-His");

				//gzip
				if (x("gzip")) {
					ob_end_clean();
					header("Content-type: application/x-gzip");
					header("Content-Disposition: attachment; filename=\"{$prefix}.gz\"");
					echo gzcompress($this->contents, 9);
					exit();
				}
				else {
					ob_end_clean();
					header("Content-type: application/octet-stream");
					header("Content-Disposition: attachment; filename=\"{$prefix}.js\"");
					echo $this->contents;
					exit();
				}
			}
		}

		$this->display();
	}


public function doDbExport() {
    $this->db = xn("db");
   
    $gzip = (bool)x("gzip");
   
    // ✅ Use a tmp folder inside your project instead of /root
    $baseDir = __DIR__ . "/../tmp/dbexports";
    if (!is_dir($baseDir)) {
        mkdir($baseDir, 0755, true);
    }

    $outputDir = "$baseDir/{$this->db}";
    if (!is_dir($outputDir)) {
        mkdir($outputDir, 0755, true);
    }

    // ✅ Select database
    $db = $this->_mongo->selectDB($this->db);
   // $collections = MDb::listCollections($db);
$this->collections =$db->listCollections();
    $this->selectedCollections = [];

    if (!$this->isPost()) {
        $this->selectedCollections[] = xn("collection");
    } else {
        $checkeds = xn("checked");
        if (is_array($checkeds)) {
            $this->selectedCollections = array_keys($checkeds);
        } else {
            $this->selectedCollections = $collections;
        }

        sort($this->selectedCollections);

        // ✅ Export each collection
        foreach ($this->selectedCollections as $collection) {
            $coll = $db->selectCollection($collection);
            // call your RMongoCollection export method
            $coll->export($outputDir, false);
        }

        // ✅ Handle compression (zip or gz)
        
        
        
  $this->make_zip($outputDir,$baseDir,"$this->db.zip");      
$zipPath = "$baseDir/{$this->db}.zip";
if (file_exists($zipPath) && filesize($zipPath) > 0) {
                // ✅ SUCCESS: Clear all output buffers and send ZIP file
                ob_end_clean();
                
                header("Content-Type: application/zip");
                header("Content-Disposition: attachment; filename=\"{$this->db}.zip\"");
                header("Content-Length: " . filesize($zipPath));
                header("Cache-Control: no-cache, must-revalidate");
                header("Pragma: no-cache");
                header("Expires: 0");
                
                readfile($zipPath);
                
                // Cleanup
                unlink($zipPath);
                $this->rrmdir($outputDir);
                exit;
            } else {
                $this->rrmdir($outputDir);
                ob_end_clean();
                echo json_encode(["status" => "error", "message" => "ZIP file was created but is empty"]);
                exit;
            }


/*
$zipPath = "$baseDir/{$this->db}.zip";
$zip = new ZipArchive();

// First, verify the source directory exists and has files
if (!is_dir($outputDir) || !is_readable($outputDir)) {
    echo json_encode(["status" => "error", "message" => "Source directory doesn't exist or is not readable"]);
    exit;
}

// Count files before creating ZIP
$fileCount = 0;
$files = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($outputDir, RecursiveDirectoryIterator::SKIP_DOTS),
    RecursiveIteratorIterator::LEAVES_ONLY
);

foreach ($files as $file) {
    $fileCount++;
}

if ($fileCount === 0) {
    echo json_encode(["status" => "error", "message" => "No files found to add to ZIP archive"]);
    exit;
}

echo "Found $fileCount files to add to ZIP<br>";

// Create the ZIP
$result = $zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE);
if ($result === TRUE) {
    $addedFiles = 0;
    
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($outputDir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );

    foreach ($files as $file) {
        $filePath = $file->getRealPath();
        
        // Skip directories, only add files
        if (!$file->isDir()) {
            $relativePath = str_replace($outputDir . DIRECTORY_SEPARATOR, '', $filePath);
            
            if ($zip->addFile($filePath, $relativePath)) {
                $addedFiles++;
            } else {
                error_log("Failed to add file: $filePath");
            }
        }
    }
    
    echo "Successfully added $addedFiles files to ZIP<br>";
    
    if ($addedFiles === 0) {
        $zip->close();
        unlink($zipPath); // Remove empty ZIP
        echo json_encode(["status" => "error", "message" => "No files were added to ZIP archive"]);
        exit;
    }
    
    if (!$zip->close()) {
        echo json_encode(["status" => "error", "message" => "Failed to close ZIP archive"]);
        exit;
    }
    
    // Verify the ZIP was created properly
    if (file_exists($zipPath) && filesize($zipPath) > 0) {
        echo "ZIP created successfully. File size: " . filesize($zipPath) . " bytes<br>";
    } else {
        echo json_encode(["status" => "error", "message" => "ZIP file was created but is empty"]);
        exit;
    }
    
} else {
    echo json_encode(["status" => "error", "message" => "Failed to create ZIP archive. Error code: $result"]);
    exit;
}

*/
      
/*
 $zipPath = "$baseDir/{$this->db}.zip";

// Create ZIP using system command (fast & reliable)
$cmd = "cd " . escapeshellarg($outputDir) . " && zip -r " . escapeshellarg($zipPath) . " .";
system($cmd, $returnCode);

if ($returnCode === 0 && file_exists($zipPath)) {
    header("Content-Type: application/zip");
    header("Content-Disposition: attachment; filename=\"{$this->db}.zip\"");
    header("Content-Length: " . filesize($zipPath));
    readfile($zipPath);

    // Cleanup
    unlink($zipPath);
    $this->rrmdir($outputDir);
    exit;
} else {
    error_log("Failed to create zip file. Return code: $returnCode");
}
*/
 
   
       
        
    }

    $this->display();
}
public function doDbExportbox() {
    // Start output buffering immediately to prevent any output corruption
    ob_start();
    
    $this->db = xn("db");
    $gzip = (bool)x("gzip");

    // ✅ Use a tmp folder inside your project instead of /root
    $baseDir = __DIR__ . "/../tmp/dbexports";
    if (!is_dir($baseDir)) {
        mkdir($baseDir, 0755, true);
    }

    $outputDir = "$baseDir/{$this->db}";
    if (!is_dir($outputDir)) {
        mkdir($outputDir, 0755, true);
    }

    // ✅ Select database
    $db = $this->_mongo->selectDB($this->db);
    $this->collections = $db->listCollections();
    $this->selectedCollections = [];

    if (!$this->isPost()) {
        $this->selectedCollections[] = xn("collection");
        $this->display();
        return;
    } else {
        $checkeds = xn("checked");
        if (is_array($checkeds)) {
            $this->selectedCollections = array_keys($checkeds);
        } else {
            // Use the actual collections list
            $this->selectedCollections = [];
            foreach ($this->collections as $collection) {
                $this->selectedCollections[] = $collection->getName();
            }
        }

        sort($this->selectedCollections);

        // ✅ Export each collection
        foreach ($this->selectedCollections as $collection) {
            $coll = $db->selectCollection($collection);
            // call your RMongoCollection export method
            $coll->export($outputDir, false);
        }

        // ✅ Create ZIP file
        $zipPath = "$baseDir/{$this->db}.zip";
        $zip = new ZipArchive();

        // First, verify the source directory exists and has files
        if (!is_dir($outputDir) || !is_readable($outputDir)) {
            // Clean any output buffer and send JSON error
            ob_end_clean();
            echo json_encode(["status" => "error", "message" => "Source directory doesn't exist or is not readable"]);
            exit;
        }

        // Count files before creating ZIP
        $fileCount = 0;
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($outputDir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($files as $file) {
            if (!$file->isDir()) {
                $fileCount++;
            }
        }

        if ($fileCount === 0) {
            // Cleanup before error
            $this->rrmdir($outputDir);
            ob_end_clean();
            echo json_encode(["status" => "error", "message" => "No files found to add to ZIP archive"]);
            exit;
        }

        // Create the ZIP
        $result = $zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE);
        if ($result === TRUE) {
            $addedFiles = 0;
            
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($outputDir, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );

            foreach ($files as $file) {
                $filePath = $file->getRealPath();
                
                // Skip directories, only add files
                if (!$file->isDir()) {
                    $relativePath = str_replace($outputDir . DIRECTORY_SEPARATOR, '', $filePath);
                    
                    if ($zip->addFile($filePath, $relativePath)) {
                        $addedFiles++;
                    }
                }
            }
            
            if ($addedFiles === 0) {
                $zip->close();
                unlink($zipPath);
                $this->rrmdir($outputDir);
                ob_end_clean();
                echo json_encode(["status" => "error", "message" => "No files were added to ZIP archive"]);
                exit;
            }
            
            if (!$zip->close()) {
                $this->rrmdir($outputDir);
                ob_end_clean();
                echo json_encode(["status" => "error", "message" => "Failed to close ZIP archive"]);
                exit;
            }
            
            // Verify the ZIP was created properly
            if (file_exists($zipPath) && filesize($zipPath) > 0) {
                // ✅ SUCCESS: Clear all output buffers and send ZIP file
                ob_end_clean();
                
                header("Content-Type: application/zip");
                header("Content-Disposition: attachment; filename=\"{$this->db}.zip\"");
                header("Content-Length: " . filesize($zipPath));
                header("Cache-Control: no-cache, must-revalidate");
                header("Pragma: no-cache");
                header("Expires: 0");
                
                readfile($zipPath);
                
                // Cleanup
                unlink($zipPath);
                $this->rrmdir($outputDir);
                exit;
            } else {
                $this->rrmdir($outputDir);
                ob_end_clean();
                echo json_encode(["status" => "error", "message" => "ZIP file was created but is empty"]);
                exit;
            }
            
        } else {
            $this->rrmdir($outputDir);
            ob_end_clean();
            echo json_encode(["status" => "error", "message" => "Failed to create ZIP archive. Error code: $result"]);
            exit;
        }
    }
}

public function doDbImportnormal() {
    $this->db = xn("db");

    if ($this->isPost()) {
        if (!empty($_FILES["json"]["tmp_name"])) {
            $tmp = $_FILES["json"]["tmp_name"];
            $filename = $_FILES["json"]["name"];
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

            $db = $this->_mongo->selectDB($this->db);
$baseDir = realpath(__DIR__ . "/../tmp");
            if (!$baseDir) {
                $baseDir = __DIR__ . "/../tmp";
            }
            // --- Prepare temporary directory ---
            $outputDir = "$baseDir/dbimport/{$this->db}";
            if (is_dir($outputDir)) {
                $this->rrmdir($outputDir);
            }
            mkdir($outputDir, 0755, true);

            // --- Detect and Extract File ---
            if ($ext === "zip") {
                $zip = new ZipArchive();
                if ($zip->open($tmp) === true) {
                    // ✅ Secure extract
                    for ($i = 0; $i < $zip->numFiles; $i++) {
                        $stat = $zip->statIndex($i);
                        $name = $stat['name'];
                        if (strpos($name, '..') !== false) continue; // prevent traversal
                    }
                    $zip->extractTo($outputDir);
                    $zip->close();
                } else {
                    $this->error2 = "❌ Failed to open ZIP archive.";
                    return $this->display();
                }

            } elseif ($ext === "gz" || $ext === "tar") {
                $tarPath = "$outputDir/temp.tar.gz";
                copy($tmp, $tarPath);
                system("tar -xzf " . escapeshellarg($tarPath) . " -C " . escapeshellarg($outputDir));
                @unlink($tarPath);

            } else {
                // Single BSON/JSON file upload
                copy($tmp, "$outputDir/" . basename($filename));
            }

            // --- Import Logic ---
            try {
                $db->import($outputDir); // ✅ Use correct folder
                $this->message2 = "✅ Database import completed successfully.";

                // Cleanup only after success
               // $this->rrmdir($outputDir);

            } catch (Exception $e) {
                $this->error2 = "❌ Import failed: " . $e->getMessage();
            }

        } else {
            $this->error2 = "⚠️ No file uploaded or upload failed.";
        }
    }

    $this->display();
}

public function doDbImport() {
    $this->db = xn("db");

    // --- Handle AJAX Upload ---
    if ($this->isPost()) {
        header('Content-Type: application/json');
        ob_clean(); // clear any buffered HTML

        if (!empty($_FILES["json"]["tmp_name"])) {
            $tmp = $_FILES["json"]["tmp_name"];
            $filename = $_FILES["json"]["name"];
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

            // --- Allowed formats ---
            $allowed = ["zip", "bjson", "gz", "tar", "json"];
            if (!in_array($ext, $allowed)) {
                echo json_encode([
                    "status" => "error",
                    "message" => "❌ Invalid file format. Allowed: .zip, .bjson, .gz, .tar, .json"
                ]);
                exit;
            }

            // --- Rename file with timestamp ---
            $timestamp = date("Ymd_His");
            $safeName = preg_replace("/[^a-zA-Z0-9_\-\.]/", "_", pathinfo($filename, PATHINFO_FILENAME));
            $newFilename = "{$safeName}_{$timestamp}.{$ext}";

            $db = $this->_mongo->selectDB($this->db);
            $baseDir = realpath(__DIR__ . "/../tmp") ?: (__DIR__ . "/../tmp");
            $outputDir = "$baseDir/dbimport/{$this->db}";

            if (is_dir($outputDir)) {
                $this->rrmdir($outputDir);
            }
            mkdir($outputDir, 0755, true);

            // --- Move uploaded file ---
            $uploadedPath = "$outputDir/$newFilename";
            if (!move_uploaded_file($tmp, $uploadedPath)) {
                echo json_encode(["status" => "error", "message" => "❌ Failed to move uploaded file."]);
                exit;
            }

            // --- Detect and Extract File ---
            if ($ext === "zip") {
    $zip = new ZipArchive();
    $result = $zip->open($uploadedPath);
    
    if ($result === TRUE) {
        // Create output directory if it doesn't exist
        if (!is_dir($outputDir)) {
            mkdir($outputDir, 0755, true);
        }
        
        // Security check and extraction
        $safeToExtract = true;
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            $name = $stat['name'];
            
            // Enhanced security checks
            if (strpos($name, '..') !== false || 
                strpos($name, '/') === 0 || 
                strpos($name, '\\') === 0) {
                $safeToExtract = false;
                break;
            }
        }
        
        if ($safeToExtract) {
            if ($zip->extractTo($outputDir)) {
                $zip->close();
            } else {
                echo json_encode(["status" => "error", "message" => "Failed to extract ZIP archive"]);
                exit;
            }
        } else {
            $zip->close();
            echo json_encode(["status" => "error", "message" => "ZIP archive contains potentially unsafe files"]);
            exit;
        }
    } else {
        // More detailed error messages
        $errorMessages = [
            ZipArchive::ER_EXISTS => "File already exists",
            ZipArchive::ER_INCONS => "Zip archive inconsistent",
            ZipArchive::ER_INVAL => "Invalid argument",
            ZipArchive::ER_MEMORY => "Malloc failure",
            ZipArchive::ER_NOENT => "No such file",
            ZipArchive::ER_NOZIP => "Not a zip archive",
            ZipArchive::ER_OPEN => "Can't open file",
            ZipArchive::ER_READ => "Read error",
            ZipArchive::ER_SEEK => "Seek error",
        ];
        
        $errorMsg = isset($errorMessages[$result]) ? $errorMessages[$result] : "Unknown error ($result)";
        echo json_encode(["status" => "error", "message" => "Failed to open ZIP archive: $errorMsg"]);
        exit;
    }
} elseif (in_array($ext, ["gz", "tar"])) {
                $tarPath = "$outputDir/temp.tar.gz";
                rename($uploadedPath, $tarPath);
                system("tar -xzf " . escapeshellarg($tarPath) . " -C " . escapeshellarg($outputDir));
                @unlink($tarPath);

            } else {
                // Single BSON/JSON file
                // Already moved as $uploadedPath
            }

            // --- Import Logic ---
            try {
                $resultLog = $db->import($outputDir);
                echo json_encode([
                    "status" => "success",
                    "message" => "✅ File imported successfully: <strong>$newFilename</strong><br><br>" . nl2br($resultLog)
                ]);
                exit;

            } catch (Exception $e) {
                echo json_encode([
                    "status" => "error",
                    "message" => "❌ Import failed: " . $e->getMessage()
                ]);
                exit;
            }

        } else {
            echo json_encode([
                "status" => "error",
                "message" => "⚠️ No file uploaded or upload failed."
            ]);
            exit;
        }
    }

    // --- Render HTML form ---
    $this->display();
}


	/** import db **/
public function doDbImportxx() {
    $this->db = xn("db");

    if ($this->isPost()) {
        $format = x("format");

        if (!empty($_FILES["json"]["tmp_name"])) {
            $tmp = $_FILES["json"]["tmp_name"];

            // Read file content (support .gz)
            if (preg_match("/\\.gz$/", $_FILES["json"]["name"])) {
                $body = gzdecode(file_get_contents($tmp));
            } else {
                $body = file_get_contents($tmp);
            }

            $ret = ["ok" => 0];
            $manager = null;

            // Get MongoDB Manager from RMongo
            if (property_exists($this->_mongo, '_mongo')) {
                $ref = new ReflectionClass($this->_mongo);
                if ($ref->hasProperty('_mongo')) {
                    $prop = $ref->getProperty('_mongo');
                    $prop->setAccessible(true);
                    $manager = $prop->getValue($this->_mongo);
                }
            }

            if (!$manager instanceof MongoDB\Driver\Manager) {
                throw new Exception("MongoDB Manager not found inside RMongo instance");
            }

            $collection = trim(xn("collection"));
            if ($collection === "") {
                $this->error2 = "Please enter the collection name.";
            } else {
                $dbName = $this->db;

                // 🧩 Auto-convert old JS dump format to JSON lines
                if ($format == "js" || preg_match('/db\.getCollection/', $body)) {
                    // Remove comments and unnecessary commands
                    $body = preg_replace('/\/\*.*?\*\//s', '', $body); // remove /* comments */
                    $body = preg_replace('/db\.getCollection\(".*?"\)\.insert\((.*?)\);/s', '$1', $body);
                    $body = preg_replace('/db\.getCollection\(".*?"\)\.ensureIndex\(.*?\);/s', '', $body);
                    $body = preg_replace('/NumberInt\((\d+)\)/', '$1', $body);
                    $body = preg_replace('/ObjectId\("([0-9a-f]+)"\)/i', '{"$oid":"$1"}', $body);
                    $body = trim($body);

                    // Split into lines
                    $lines = preg_split('/\n+/', $body);
                } else {
                    $lines = explode("\n", $body);
                }

                $success = 0;
                $fail = 0;

                foreach ($lines as $line) {
                    $line = trim($line);
                    if ($line) {
                        $doc = json_decode($line, true);

                        // Handle multi-line JSON objects
                        if (json_last_error() !== JSON_ERROR_NONE) {
                            static $buffer = "";
                            $buffer .= $line;
                            $doc = json_decode($buffer, true);
                            if (json_last_error() === JSON_ERROR_NONE) {
                                $line = $buffer;
                                $buffer = "";
                            } else {
                                continue;
                            }
                        }

                        if (is_array($doc)) {
                            try {
                                $bulk = new MongoDB\Driver\BulkWrite;
                                $bulk->insert($doc);
                                $manager->executeBulkWrite("$dbName.$collection", $bulk);
                                $success++;
                            } catch (Exception $e) {
                                $fail++;
                            }
                        } else {
                            $fail++;
                        }
                    }
                }

                if ($fail > 0 && $success == 0) {
                    $this->error2 = "No documents imported. Check your file format.";
                } elseif ($fail > 0) {
                    $this->message2 = "$success documents imported successfully. $fail failed.";
                } else {
                    $this->message2 = "All data imported successfully.";
                }

                $ret["ok"] = 1;
            }
        } else {
            $msg = "Either no file input or file is too large to upload.";
            if ($format == "js") {
                $this->error = $msg;
            } else {
                $this->error2 = $msg;
            }
        }
    }

    $this->display();
}

	/** db profiling **/
	public function doProfile() {
		$this->db = xn("db");

		import("lib.mongo.RQuery");
		import("lib.page.RPageStyle1");
		$query = new RQuery($this->_mongo, $this->db, "system.profile");
		$page = new RPageStyle1();
		$page->setTotal($query->count());
		$page->setSize(10);
		$page->setAutoQuery();
		$this->page = $page;

		$this->rows = $query
			->offset($page->offset())
			->limit($page->size())
			->desc("ts")
			->findAll();
		foreach ($this->rows as $index => $row) {
			$this->rows[$index]["text"] = $this->_highlight($row, "json");
		}

		$this->display();
	}

	/** change db profiling level **/
	public function doProfileLevel() {
		$this->db = xn("db");

		$db = $this->_mongo->selectDB($this->db);
		$query1 = $db->execute("function (){ return db.getProfilingLevel(); }");
		$this->level = $query1["retval"];
		if (x("go") == "save_level") {
			$level = xi("level");
			$slowms = xi("slowms");
			$db->execute("function(level,slowms) { db.setProfilingLevel(level,slowms); }", array($level, $slowms));
			$this->level = $level;
		}
		else {
			x("slowms", 50);
		}
		$this->display();
	}

	/** clear profiling data **/
	public function doClearProfile() {
		$this->db = xn("db");
		$db = $this->_mongo->selectDB($this->db);

		$query1 = $db->execute("function (){ return db.getProfilingLevel(); }");
		$oldLevel = $query1["retval"];
		$db->execute("function(level) { db.setProfilingLevel(level); }", array(0));
		$ret = $db->selectCollection("system.profile")->drop();
		$db->execute("function(level) { db.setProfilingLevel(level); }", array($oldLevel));

		$this->redirect("db.profile", array(
			"db" => $this->db
		));
	}

	/** authentication **/
	public function doAuth() {
		$this->db = xn("db");
		$db = $this->_mongo->selectDB($this->db);

		//users
		$collection = $db->selectCollection("system.users");
		$cursor = $collection->find();
		$this->users= array();
		while($cursor->hasNext()) {
			$this->users[] = $cursor->getNext();
		}

		$this->display();
	}

	/** delete user **/
	public function doDeleteUser() {
		$this->db = xn("db");
		$db = $this->_mongo->selectDB($this->db);

		$db->execute("function (username){ db.removeUser(username); }", array(xn("user")));
		$this->redirect("db.auth", array(
			"db" => $this->db
		));
	}

	/** add user **/
	public function doAddUser() {
		$this->db = xn("db");

		if (!$this->isPost()) {
			$this->display();
			return;
		}

		$username = trim(xn("username"));
		$password = trim(xn("password"));
		$password2 = trim(xn("password2"));
		if ($username == "") {
			$this->error = "You must supply a username for user.";
			$this->display();
			return;
		}
		if ($password == "") {
			$this->error = "You must supply a password for user.";
			$this->display();
			return;
		}
		if ($password != $password2) {
			$this->error = "Passwords you typed twice is not same.";
			$this->display();
			return;
		}
		$db = $this->_mongo->selectDB($this->db);
		$db->execute("function (username, pass, readonly){ db.addUser(username, pass, readonly); }", array(
			$username,
			$password,
			x("readonly") ? true : false
		));

		$this->redirect("auth", array(
			"db" => $this->db
		));
	}

	/** create new collection **/
	public function doNewCollection() {
		$this->db = xn("db");
		$this->name = trim(xn("name"));
		$this->isCapped = xi("is_capped");
		$this->size = xi("size");
		$this->max = xi("max");

		if ($this->isPost()) {
			$db = $this->_mongo->selectDB($this->db);

			MCollection::createCollection($db, $this->name, array(
				"capped" => $this->isCapped,
				"size" => $this->size,
				"max" => $this->max
			));
			$this->message = "New collection is created. <a href=\"?action=collection.index&db={$this->db}&collection={$this->name}\">[GO &raquo;]</a>";

			//add index
			if (!$this->isCapped) {
				$db->selectCollection($this->name)->ensureIndex(array( "_id" => 1 ));
			}
		}

		$this->display();
	}

	/** drop all collections in a db **/
	public function doDropDbCollections() {
		$this->db = xn("db");
		$db = $this->_mongo->selectDB($this->db);
		foreach ($db->listCollections() as $collection) {
			$collection->drop();
		}
		echo '<script language="javascript">
window.parent.frames["left"].location.reload();
</script>';
		$this->redirect("db.index", array( "db" => $this->db ), true);
	}

	/** clear all records in all collections **/
	public function doClearDbCollections() {
		$this->db = xn("db");
		$db = $this->_mongo->selectDB($this->db);
		foreach ($db->listCollections() as $collection) {
			$collection->remove();
		}
		echo '<script language="javascript">
window.parent.frames["left"].location.reload();
</script>';
		$this->redirect("db.index", array( "db" => $this->db ), true);
	}

	/** repair dataase **/
	public function doRepairDatabase() {
		$this->db = xn("db");

		$db = $this->_mongo->selectDB($this->db);
		$ret = $db->command(array( "repairDatabase" => 1 ));
		//$ret = $db->execute('function (){ return db.repairDatabase(); }'); //occure error in current version, we did not know why?
		$this->ret = $this->_highlight($ret, "json");
		$this->display();
	}

	/** drop database **/
	public function doDropDatabase() {
		$this->db = xn("db");

		if (!x("confirm")) {
			$this->display();
			return;
		}

		$ret = $this->_mongo->dropDB($this->db);
		$this->ret = $this->_highlight($ret, "json");
		$this->display("dropDatabaseResult");
	}
	
private function rrmdir($dir) {
        if (!is_dir($dir)) return;
        $files = scandir($dir);
        foreach ($files as $file) {
            if ($file == '.' || $file == '..') continue;
            $path = "$dir/$file";
            is_dir($path) ? $this->rrmdir($path) : unlink($path);
        }
        rmdir($dir);
    }
    
    
private function make_zip($rootPath,$baseDir,$file_name){

$rootPath = rtrim($rootPath, '\\/');
$rootPath = realpath($rootPath);

$baseDir = rtrim($baseDir, '\\/');
$baseDir = realpath($baseDir);

// Initialize archive object
$zip = new ZipArchive();
$zip->open("$baseDir/$file_name", ZipArchive::CREATE | ZipArchive::OVERWRITE);

// Create recursive directory iterator
/** @var SplFileInfo[] $files */
$files = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($rootPath),
    RecursiveIteratorIterator::LEAVES_ONLY
);

foreach ($files as $file)
{
    // Skip directories (they would be added automatically)
    if (!$file->isDir())
    {
        // Get real and relative path for current file
        $filePath = $file->getRealPath();
        $relativePath = substr($filePath, strlen($rootPath) + 1);

        // Add current file to archive
        $zip->addFile($filePath, $relativePath);
    }
}

// Zip archive will be created only after closing object
$zip->close();    
}    
    
	
}

?>