<?php

import("classes.BaseController");

class LoginController extends BaseController {
	public function onBefore() {
		//render header
		if (!$this->isAjax()) {
			render_view("header");
		}
	}
	
	/**
	 * login page and post 
	 */
public function doIndex() {
    global $MONGO;

    import("models.MUser");

    $this->languages = rock_load_languages();
    $this->expires = [
        3 => "3 " . rock_lang("hours"),
        720 => "1 " . rock_lang("month"),
    ];

    $i = 0; // default to first server
    if (isset($MONGO["servers"][$i])) {
        $serverInfo = $MONGO["servers"][$i];

        // ✅ Auto-login only if server is configured AND ?auto=1 in URL
        if (!empty($serverInfo["autoLogin"]) && isset($_GET["auto"]) && $_GET["auto"] == "1") {

            // 🧹 Logout any existing session first
            if (MUser::isLogin()) {
                try {
                   session_destroy();
				   echo'<meta http-equiv="refresh" content="0"; URL="index.php?action=login.index&host=0&auto=1" />';
				   exit;
                } catch (Exception $e) {}
            }

            $this->hostIndex = $i;
            $this->username  = $serverInfo["mongo_user"] ?? "";
            $password        = $serverInfo["mongo_pass"] ?? "";
            $db              = $serverInfo["mongo_db"] ?? "admin";
            $host            = $serverInfo["mongo_host"] ?? "127.0.0.1";
            $port            = $serverInfo["mongo_port"] ?? 27017;

            $this->_mongo = new RMongo("mongodb://{$host}:{$port}");
            $result = $this->_mongo->login($this->username, $password, $db);

            if (!empty($result["ok"])) {
                // ✅ Successful auto login — save session
                MUser::login($this->username, $password, $this->hostIndex, $db, 720 * 3600);
                setcookie("ROCK_LANG", (string)(x("lang") ?? ""), time() + 365 * 86400);

                // ✅ Redirect to dashboard
                $this->redirect("admin.index", ["host" => $this->hostIndex]);
                return;
            } else {
                // ❌ Auto login failed
                $this->message = "Auto-login failed: " . ($result["errmsg"] ?? "Unknown error");
                $this->display();
                return;
            }
        }else if (empty($serverInfo["manualLogin"])) {
          echo"Manual login is disabled. To enable it, set manualLogin to true in config.php";
           exit; 
        }
    }

    // 🔐 Normal manual login process
    if ($this->isPost()) {
        $this->username = trim(xn("username") ?? '');
        $this->db = trim(xn("db"));
        $password = trim(xn("password") ?? '');
        $this->hostIndex = xi("host") ?? 0;

        if (!isset($MONGO["servers"][$this->hostIndex])) {
            $this->message = "Server does not exist";
            $this->display();
            return;
        }

        $serverInfo = $MONGO["servers"][$this->hostIndex];
        $host = $serverInfo["mongo_host"] ?? "127.0.0.1";
        $port = $serverInfo["mongo_port"] ?? 27017;
        $db = !empty($this->db) ? $this->db : "admin";

        $this->_mongo = new RMongo("mongodb://{$host}:{$port}");
        $result = $this->_mongo->login($this->username, $password, $db);

        if (!empty($result["ok"])) {
            // ✅ Save session for manual login
            MUser::login($this->username, $password, $this->hostIndex, $db, xi("expire") * 3600);
            setcookie("ROCK_LANG", (string)(x("lang") ?? ""), time() + 365 * 86400);
            $this->redirect("admin.index", ["host" => $this->hostIndex]);
            return;
        } else {
            $this->message = rock_lang("can_not_auth") . ": " . ($result["errmsg"] ?? "Unknown error");
        }
    }

    // 🧭 Default: show login page
    $this->display();
}


public function doAuto() {
    global $MONGO;

  
    $this->languages = rock_load_languages();
    $this->expires = [
        3 => "3 " . rock_lang("hours"),
        720 => "1 " . rock_lang("month"),
    ];
    $this->moreOptions = xi("more");

      $i = 0;
    if (isset($MONGO["servers"][$i])) {
        $serverInfo = $MONGO["servers"][$i];
       //  @session_destroy();
     
        
$this->hostIndex=$i;
     
        // Check if the server exists
        if (!isset($MONGO["servers"][$this->hostIndex])) {
            $this->message = "Server does not exist";
            $this->display();
            return;
        }

        // Get server details
        $serverInfo = $MONGO["servers"][$this->hostIndex];
        $host = $serverInfo["host"] ?? "127.0.0.1";
        $port = $serverInfo["port"] ?? 27017;
     
       $this->username = $serverInfo["mongo_user"] ?? "";
            $password = $serverInfo["mongo_pass"] ?? "";
            $db   = $serverInfo["mongo_db"] ?? "admin";
        // ✅ Initialize RMongo with host and port
        $this->_mongo = new RMongo("mongodb://{$host}:{$port}");

        // ✅ Authenticate using RMongo’s login method
        $result = $this->_mongo->login($this->username, $password, $db);

        if (!$result["ok"]) {
            $this->message = rock_lang("can_not_auth") . ": " . $result["errmsg"];
            $this->display();
            return;
        }
 
        // ✅ Save session
        import("models.MUser");
        MUser::login($this->username, $password, $this->hostIndex, $db, xi("expire") * 3600);

        // Save selected language
        setcookie("ROCK_LANG", x("lang"), time() + 365 * 86400);

        // Redirect to admin dashboard
        $this->redirect("admin.index", ["host" => $this->hostIndex]);
    } else {
        $this->display();
    }
}





}

?>