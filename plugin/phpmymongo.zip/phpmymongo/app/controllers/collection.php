<?php

import("classes.BaseController");

/**
 * collection controller
 *
 * You should always input these parameters:
 * - db
 * - collection
 * to call the actions.
 *
 * @author iwind
 *
 */
class CollectionController extends BaseController {
	/**
	 * DB Name
	 *
	 * @var string
	 */
	public $db;

	/**
	 * Collection Name
	 *
	 * @var string
	 */
	public $collection;

	/**
	 * DB instance
	 *
	 * @var MongoDB
	 */
	protected $_mongodb;

	public function onBefore() {
		parent::onBefore();
		$this->db = xn("db");
		$this->collection = xn("collection");
		$this->_mongodb = $this->_mongo->selectDB($this->db);
	}

	/**
	 * load single record
	 *
	 */
public function doRecord() {
    $rawId = xn("id");

    // 1️⃣ Decode using RockMongo’s built-in ID decoder
    $decoded = rock_real_id($rawId);

    // 2️⃣ Extract real value if it's nested (array/object cases)
    if (is_array($decoded)) {
        if (isset($decoded['$oid'])) {
            $id = $decoded['$oid'];
        } elseif (isset($decoded['_id']['$oid'])) {
            $id = $decoded['_id']['$oid'];
        } elseif (isset($decoded['_id'])) {
            $id = $decoded['_id'];
        } else {
            $id = reset($decoded);
        }
    } elseif (is_object($decoded)) {
        // Handle BSONObject or stdClass
        if (isset($decoded->{'$oid'})) {
            $id = (string)$decoded->{'$oid'};
        } elseif (isset($decoded->_id)) {
            $id = (string)$decoded->_id;
        } else {
            $id = (string)$decoded;
        }
    } else {
        $id = $decoded;
    }

    // 3️⃣ Fallback for string-encoded RockMongo types like rid_mixed% or rid_string:
    if (is_string($id) && str_starts_with($id, 'rid_')) {
        $id = rock_real_id($id);
        if (is_array($id) && isset($id['$oid'])) {
            $id = $id['$oid'];
        }
    }

    // 4️⃣ Detect valid ObjectId pattern
    $isObjectId = is_string($id) && preg_match('/^[a-f0-9]{24}$/i', $id);

    // 5️⃣ Build final MongoDB filter
    $filter = $isObjectId ? ['_id' => new MongoDB\BSON\ObjectId($id)] : ['_id' => $id];

    // ✅ use new MongoDB syntax for projection fields
    $queryFields = x("query_fields");
    $fields = [];
    if (!empty($queryFields)) {
        foreach ($queryFields as $queryField) {
            $fields[$queryField] = 1;
        }
    }

    // ✅ ensure database and collection objects exist
    $dbName = x("db");
    $collectionName = xn("collection");
    $collection = $this->_mongo->selectDB($dbName)->selectCollection($collectionName);

    $row = $collection->findOne($filter, ['projection' => $fields]);
    if (empty($row)) {
        $this->_outputJson(["code" => 300, "message" => "The record has been removed."]);
    }

    $format = xn("format");
    $exporter = new VarExportor($this->_mongodb, $row);
    $data = $exporter->export($format);
    $html = $this->_highlight($row, $format, true);

    $this->_outputJson(["code" => 200, "data" => $data, "html" => $html]);
}

	/**
	 * switch format between array and json
	 */
	public function doSwitchFormat() {
		$data = xn("data");
		$format = x("format");

		$ret = null;
		if ($format == "json") {//to json
			$eval = new VarEval($data, "array", $this->_mongodb);
			$array = $eval->execute();
			$exportor = new VarExportor($this->_mongodb, $array);
			$ret = json_unicode_to_utf8($exportor->export(MONGO_EXPORT_JSON));
		}
		else if ($format == "array") {//to array
			$eval = new VarEval($data, "json", $this->_mongodb);
			$array = $eval->execute();

			$exportor = new VarExportor($this->_mongodb, $array);
			$ret = $exportor->export(MONGO_EXPORT_PHP);
		}
		$this->_outputJson(array("code" => 200, "data" => $ret));
	}

	/** show one collection **/
public function doIndex() {
    $this->db = xn("db");
    $this->collection = xn("collection");
    $this->last_format = rock_cookie("rock_format", "json");

    $params = xn();
    if ($this->_logQuery && count($params) > 3) {
        $logDir = dirname(__ROOT__) . DS . "logs";
        if (!empty($params["criteria"]) && strlen(trim($params["criteria"], "{} \t\n\r")) > 0) {
            if (is_writable($logDir)) {
                $logFile = $this->_logFile($this->db, $this->collection);
                $fp = fopen($logFile, "a+");
                if (filesize($logFile) == 0) {
                    fwrite($fp, '<?php exit("Permission Denied"); ?>' . "\n");
                }
                fwrite($fp, date("Y-m-d H:i:s") . "\n" . var_export($params, true) . "\n================\n");
                fclose($fp);
            }
        }
    }

    // Use RMongo directly
    $db = $this->_mongo->selectDatabase($this->db);
    $collection = $db->selectCollection($this->collection);

    $info = MCollection::info($db, $this->collection);
    $this->canAddField = !$info["capped"];

    // Sort field setup
    $fields = xn("field");
    $orders = xn("order");
    if (empty($fields)) {
        if (!$this->_server->docsNatureOrder()) {
            $fields = [($info["capped"]) ? "\$natural" : "_id", "", "", ""];
        } else {
            $fields = [];
        }
        $orders = ["desc", "asc", "asc", "asc"];
        x("field", $fields);
        x("order", $orders);
    }

    // Format
    $format = x("format") ?: $this->last_format;
    x("format", $format);
    $this->last_format = $format;
    $this->_rememberFormat($format);

    import("models.MCollection");
    $this->nativeFields = MCollection::fields($db, $this->collection);
    $this->queryFields = is_array(x("query_fields")) ? x("query_fields") : [];
    $this->queryHints = is_array(x("query_hints")) ? x("query_hints") : [];

    // Index info
    try {
        $indexes = iterator_to_array($collection->listIndexes());
        $this->indexFields = [];
        foreach ($indexes as $indexInfo) {
            $keyArray = (array)$indexInfo->getKey();
            $this->indexFields[] = [
                "name" => $indexInfo->getName(),
                "key" => $keyArray,
                "keystring" => $this->_encodeJson($keyArray),
                "unique" => $indexInfo->isUnique() ?? false
            ];
        }
        $this->recordsCount = $collection->countDocuments();
    } catch (Exception $e) {
        $this->indexFields = [];
        $this->recordsCount = 0;
        error_log("[ERROR] Failed to read indexes/count: " . $e->getMessage());
    }

    // Prepare new object
    $val = xn("newobj");
    $newobj = $val !== null ? trim($val) : "";
    if (!$newobj) {
        if ($format == "array") {
            x("newobj", 'array(
    \'$set\' => array (
        //your attributes
    )
)');
        } else {
            x("newobj", '{
    \'$set\': {
        //your attributes
    }
}');
        }
    }

    // Criteria
    $native = xn("criteria");
    $criteria = $native;
    if (empty($criteria)) {
        $criteria = [];
        $native = ($format == "array") ? "array(\n\t\n)" : "{\n\n}";
        x("pagesize", 10);
    } else {
        $eval = new VarEval($criteria, $format, $db);
        $row = $eval->execute();
        if (is_object($row)) $row = get_object_vars($row);
        if (!is_array($row)) {
            $this->message = "Criteria must be a valid " . (($format == "json") ? "JSON object" : "array");
            $this->jsonLink = "#";
            $this->arrayLink = "#";
            $this->display();
            return;
        }
        $criteria = $row;
    }
    x("criteria", $native);

    // Sorting
    $realOrderedFields = [];
    $realOrderedOrders = [];
    $sort = [];
    foreach ($fields as $index => $field) {
        if (!empty($field)) {
            $realOrderedFields[] = $field;
            $orderDir = ($orders[$index] ?? "asc") === "asc" ? 1 : -1;
            $realOrderedOrders[] = $orders[$index] ?? "asc";
            $sort[$field] = $orderDir;
        }
    }
    x("field", $realOrderedFields);
    x("order", $realOrderedOrders);

    // Pagination and limit
    $limit = xi("limit") ?: 0;
    $pagesize = xi("pagesize") ?: 10;
    import("lib.page.RPageStyle1");
    $page = new RPageStyle1();
    $page->setTotal($collection->countDocuments($criteria));
    $page->setSize($pagesize);
    $page->setAutoQuery();
    $this->page = $page;

    $options = [
        'limit' => $limit > 0 ? $limit : $page->size(),
        'skip' => $page->offset(),
        'sort' => $sort
    ];

    $microtime = microtime(true);

    // Fetch documents
    $this->rows = $collection->find($criteria, $options);

    // Convert _id to string
    foreach ($this->rows as $i => $row) {
        if (isset($row['_id']) && $row['_id'] instanceof MongoDB\BSON\ObjectId) {
            $row['_id'] = (string)$row['_id'];
        }
        $native = $row;
        $exportor = new VarExportor($db, $native);
        $row["text"] = $exportor->export($format);
        $row["data"] = $this->_highlight($native, $format, true);
        $row["can_delete"] = isset($row["_id"]) && !$info["capped"];
        $row["can_modify"] = isset($row["_id"]);
        $row["can_duplicate"] = isset($row["_id"]);
        $row["can_add_field"] = isset($row["_id"]) && !$info["capped"];
        $row["can_refresh"] = isset($row["_id"]);
        $this->rows[$i] = $row;
    }

    $this->cost = microtime(true) - $microtime;
    $this->display();
}

	/**
	 * output query history
	 *
	 */
	public function doQueryHistory() {
		ob_clean();

		$logs = array();
		$criterias = array();
		$this->error = null;
		if ($this->_logQuery) {
			$logFile = $this->_logFile(xn("db"), xn("collection"));
			$this->logs = array();
			if (is_file($logFile)) {
				$size = 10240;
				$fp = fopen($logFile, "r");
				fseek($fp, -$size, SEEK_END);
				$text = fread($fp, $size);
				fclose($fp);

				preg_match_all("/(\\d+\\-\\d+\\-\\d+\\s+\\d+:\\d+:\\d+)\n(.+)(={10,})/sU", $text, $match);

				foreach ($match[1] as $k => $time) {
					$eval = new VarEval($match[2][$k]);
					$params = $eval->execute();
					if (!in_array($params["criteria"], $criterias)) {
						$logs[] = array(
							"time" => $time,
							"params" => $params,
							"query" => http_build_query($params)
						);
						$criterias[] = $params["criteria"];
					}
				}

				if (!is_writeable($logFile)) {
					$this->error = "To use log_query feature, please make file '{$logFile}' writeable.";
				}
			}
			else {
				$dirname = dirname($logFile);
				if (!is_writeable($dirname)) {
					$this->error = "To use log_query feature, please make directory '{$dirname}' writeable.";
				}
			}
		}
		$this->logs = array_slice(array_reverse($logs), 0, 10);
		$this->display();
		exit();
	}

	/**
	 * Clear query history
	 */
	public function doClearQueryHistory() {
		if ($this->_logQuery) {
			$logFile = $this->_logFile(xn("db"), xn("collection"));
			if (is_file($logFile)) {
				if (@unlink($logFile)) {
					$this->_outputJson(array(
						"code" => 200
					));
				}
				else {
					$this->_outputJson(array(
						"code" => 501
					));
				}
			}
		}

		$this->_outputJson(array(
			"code" => 200
		));
	}


	/** explain query **/
public function doExplainQuery() {
    $this->db = x("db");
    $this->collection = xn("collection");

    // ✅ Field and sort defaults
    $fields = xn("field");
    $orders = xn("order");
    $format = xn("format");

    if (empty($fields)) {
        $fields = ["_id", "", "", ""];
        $orders = ["desc", "asc", "asc", "asc"];
        x("field", $fields);
        x("order", $orders);
    }

    // ✅ Handle criteria input
    $native = xn("criteria");
    $criteria = $native;

    if (empty($criteria)) {
        $criteria = [];
        $native = "array(\n\t\n)";
    } else {
        $eval = new VarEval($criteria, $format, $this->_mongo->selectDB($this->db));
        $row = $eval->execute();

        if (!is_array($row)) {
            $this->error = "To explain a query, criteria must be an array.";
            $this->display();
            return;
        }

        $criteria = $row;
    }

    x("criteria", $native);

    // ✅ Prepare collection
    $db = $this->_mongo->selectDB($this->db);
    $collection = $db->selectCollection($this->collection);

    // ✅ Build sort options
    $sort = [];
    foreach ($fields as $index => $field) {
        if (!empty($field)) {
            $sort[$field] = ($orders[$index] == "asc") ? 1 : -1;
        }
    }

    // ✅ Handle query hints (index selection)
    $queryHints = x("query_hints");
    $options = [];

    if (!empty($queryHints)) {
        $indexes = $collection->getIndexInfo();
        foreach ($indexes as $index) {
            if (in_array($index["name"], $queryHints)) {
                $options['hint'] = $index["key"];
                break;
            }
        }
    }

    if (!empty($sort)) {
        $options['sort'] = $sort;
    }

    // ✅ Handle command
    $command = x("command");
    if (!$command) {
        $command = "findAll";
        x("command", $command);
    }

    // ✅ Execute query with explain
    try {
    // Get internal MongoDB Manager from RMongo instance (no class change needed)
    $manager = null;
    if (property_exists($this->_mongo, '_mongo')) {
        $ref = new ReflectionClass($this->_mongo);
        if ($ref->hasProperty('_mongo')) {
            $prop = $ref->getProperty('_mongo');
            $prop->setAccessible(true);
            $manager = $prop->getValue($this->_mongo);
        }
    }

    if (!$manager instanceof MongoDB\Driver\Manager) {
        throw new Exception("MongoDB Manager not found inside RMongo instance");
    }

    // Build explain command
    $cmd = [
        'explain' => [
            'find' => $this->collection,
            'filter' => (object)$criteria,
            'sort' => (object)($options['sort'] ?? []),
        ],
        'verbosity' => 'allPlansExecution'
    ];

    $command = new MongoDB\Driver\Command($cmd);
    $cursor = $manager->executeCommand($this->db, $command);
    $result = current($cursor->toArray());

    $this->ret = $this->_highlight(json_decode(json_encode($result), true), "json");

} catch (Exception $e) {
    $this->ret = "Explain failed: " . $e->getMessage();
}


    $this->display();
}

	/** delete on row **/
public function doDeleteRow() {
    $this->db = x("db");
    $this->collection = xn("collection");

    $rawId = xn("id");

    // 1️⃣ Decode all RockMongo formats
    $decoded = rock_real_id($rawId);

    if (is_array($decoded)) {
        if (isset($decoded['$oid'])) {
            $id = $decoded['$oid'];
        } elseif (isset($decoded['_id']['$oid'])) {
            $id = $decoded['_id']['$oid'];
        } elseif (isset($decoded['_id'])) {
            $id = $decoded['_id'];
        } else {
            $id = reset($decoded);
        }
    } elseif (is_object($decoded)) {
        if (isset($decoded->{'$oid'})) {
            $id = (string)$decoded->{'$oid'};
        } elseif (isset($decoded->_id)) {
            $id = (string)$decoded->_id;
        } else {
            $id = (string)$decoded;
        }
    } else {
        $id = $decoded;
    }

    if (is_string($id) && str_starts_with($id, 'rid_')) {
        $id = rock_real_id($id);
    }

    // 2️⃣ Detect if ObjectId or plain string
    $isObjectId = is_string($id) && preg_match('/^[a-f0-9]{24}$/i', $id);
    $filter = $isObjectId ? ['_id' => new MongoDB\BSON\ObjectId($id)] : ['_id' => $id];

    try {
        // 3️⃣ Use RMongo’s built-in remove()
        $collection = $this->_mongo
            ->selectDB($this->db)
            ->selectCollection($this->collection);

        $result = $collection->remove($filter);

        if (isset($result['ok']) && $result['ok'] == 1) {
            $this->message = "Document deleted successfully.";
        } else {
            $this->error = "Delete failed: " . ($result['errmsg'] ?? "Unknown error");
        }

    } catch (Exception $e) {
        $this->error = "Delete failed: " . $e->getMessage();
    }

    $this->redirectUrl(xn("uri"), true);
}

	/** create row **/
public function doCreateRow() {
    $this->db = x("db");
    $this->collection = xn("collection");
    $id = rock_real_id(x("id"));
 if (is_array($id)) {
        if (isset($id['$oid'])) {
            $id = $id['$oid'];
        } elseif (isset($id['_id']['$oid'])) {
            $id = $id['_id']['$oid'];
        } else {
            $id = reset($id);
        }
    } else {
        $id = $rawId;
    }
    $this->last_format = rock_cookie("rock_format", "json");

    $collection = $this->_mongo->selectDB($this->db)->selectCollection($this->collection);
      //  $document = $collection->findOne($filter);

   
    // ✅ Duplicating an existing document
    if (!$this->isPost() && $id) {
        try {
            $objectId = new MongoDB\BSON\ObjectId($id);
            $row = $collection->findOne(['_id' => $objectId]);
            if (!empty($row)) {
                $row = (array)$row;
                unset($row["_id"]);

                import("classes.VarExportor");
                $export = new VarExportor($db, $row);
                x("data", $export->export($this->last_format));
            }
        } catch (Exception $e) {
            $this->error = "Invalid ID or unable to duplicate record: " . $e->getMessage();
            $this->display();
            return;
        }
    }

    // Default template
    if (!$this->isPost() && !x("data")) {
        x("data", ($this->last_format == "json") ? "{\n\t\n}" : "array(\n\n)");
    }

    // ✅ Handle submission
    if ($this->isPost()) {
        $format = x("format");
        $count = xi("count");
        $this->last_format = $format;

        $data = xn("data");
        $data = str_replace(["%{created_at}"], time(), $data);

        $eval = new VarEval($data, $format, $db);
        $row = $eval->execute();

        if ($row === false || !is_array($row)) {
            $this->error = "Data must be a valid {$format}.";
            $this->display();
            return;
        }

        try {
            for ($i = 1; $i <= $count; $i++) {
                // Auto add fields
                if (!isset($row["_id"])) {
                    $row["_id"] = new MongoDB\BSON\ObjectId();
                }
                if (!isset($row["created_at"])) {
                    $row["created_at"] = time();
                }

                // ✅ Use RMongo insert method
              //  $result = $this->_mongo->insert($this->db, $this->collection, $row);
$result = $collection->insert($row);
                if (empty($result["ok"])) {
                    throw new Exception($result["errmsg"] ?? "Unknown insert error");
                }

                // Avoid duplicate _id on next loop
                unset($row["_id"]);
            }
        } catch (Exception $e) {
            $this->error = "Insert failed: " . $e->getMessage();
            $this->display();
            return;
        }

        $this->_rememberFormat($format);

        $this->redirect("collection.index", [
            "db" => $this->db,
            "collection" => $this->collection
        ], true);
    }

    $this->display();
}

	/** modify one row **/
public function doModifyRow() {
    $this->db = xn("db");
    $this->collection = xn("collection");
    $rawId = xn("id");

// 1️⃣ Decode using RockMongo’s built-in ID decoder
$decoded = rock_real_id($rawId);

// 2️⃣ Extract real value if it's nested (array/object cases)
if (is_array($decoded)) {
    if (isset($decoded['$oid'])) {
        $id = $decoded['$oid'];
    } elseif (isset($decoded['_id']['$oid'])) {
        $id = $decoded['_id']['$oid'];
    } elseif (isset($decoded['_id'])) {
        $id = $decoded['_id'];
    } else {
        $id = reset($decoded);
    }
} elseif (is_object($decoded)) {
    // handle BSONObject or stdClass
    if (isset($decoded->{'$oid'})) {
        $id = (string)$decoded->{'$oid'};
    } elseif (isset($decoded->_id)) {
        $id = (string)$decoded->_id;
    } else {
        $id = (string)$decoded;
    }
} else {
    $id = $decoded;
}

// 3️⃣ Fallback for string-encoded RockMongo types like rid_string:authSchema1
if (is_string($id) && str_starts_with($id, 'rid_')) {
    $id = rock_real_id($id);
}

// 4️⃣ Detect valid ObjectId pattern
$isObjectId = is_string($id) && preg_match('/^[a-f0-9]{24}$/i', $id);

// 5️⃣ Build final MongoDB filter
$filter = $isObjectId ? ['_id' => new MongoDB\BSON\ObjectId($id)] : ['_id' => $id];


    // Remember last format
    $this->last_format = rock_cookie("rock_format", "json");

    try {
        // ✅ Use RMongo's native chain
        $collection = $this->_mongo->selectDB($this->db)->selectCollection($this->collection);
        $document = $collection->findOne($filter);
    } catch (Exception $e) {
        $this->error = "Failed to find record: " . $e->getMessage();
        $this->display();
        return;
    }

    if (empty($document)) {
        $this->error = "Record not found.";
        $this->display();
        return;
    }

    // ✅ Prepare data for display
    $this->row = (array)$document;
    $this->data = $this->row;
    unset($this->data["_id"]);

    import("classes.VarExportor");
    $export = new VarExportor($this->db, $this->data);
    $this->data = $export->export($this->last_format);

    if ($this->last_format === "json") {
        $this->data = json_unicode_to_utf8($this->data);
    }

    // ✅ Handle POST (update)
    if ($this->isPost()) {
        $this->data = xn("data");
        $format = x("format");
        $this->last_format = $format;

        $eval = new VarEval($this->data, $format, $this->db);
        $row = $eval->execute();

        if ($row === false || !is_array($row)) {
            $this->error = "Only valid {$format} is accepted.";
            $this->display();
            return;
        }

        try {
            // ✅ Update using your wrapper
            $updateResult = $collection->update($filter, $row);
            if (!empty($updateResult['errmsg'])) {
                throw new Exception($updateResult['errmsg']);
            }

            $this->_rememberFormat($format);
            $this->message = "Updated successfully.";
        } catch (Exception $e) {
            $this->error = "Update failed: " . $e->getMessage();
        }
    }

    $this->display();
}

	/** download file in GridFS **/
	public function doDownloadFile() {
		$this->db = xn("db");
		$this->collection = xn("collection");
		$this->id = xn("id");
		$db = $this->_mongo->selectDB($this->db);
		$prefix = substr($this->collection, 0, strrpos($this->collection, "."));
		$file = $db->getGridFS($prefix)->findOne(array("_id" => rock_real_id($this->id)));
		$fileinfo = pathinfo($file->getFilename());
		$extension = strtolower($fileinfo["extension"]);
		import("lib.mime.types", false);
		ob_end_clean();
		if (isset($GLOBALS["mime_types"][$extension])) {
			header("Content-Type:" . $GLOBALS["mime_types"][$extension]);
		}
		else {
			header("Content-Type:text/plain");
		}
		header("Content-Disposition: attachment; filename=" . $fileinfo["basename"]);
		header("Content-Length:" . $file->getSize());
		echo $file->getBytes();
		exit;
	}

	/** clear rows in collection **/
	public function doClearRows() {
    $this->db = x("db");
    $this->collection = xn("collection");

    try {
        // ✅ Select the target collection
        $collection = $this->_mongo->selectDB($this->db)->selectCollection($this->collection);

        // ✅ Remove all documents from this collection
        $collection->remove([], ['justOne' => false]);

        // ✅ Refresh left frame and redirect back to index
        echo '<script language="javascript">
            window.parent.frames["left"].location.reload();
        </script>';

        $this->redirect("collection.index", [
            "db" => $this->db,
            "collection" => $this->collection
        ], true);

    } catch (Exception $e) {
        $this->error = "Failed to clear collection: " . $e->getMessage();
        $this->display();
    }
}


	/** drop collection **/
	public function doRemoveCollection() {
		$this->db = x("db");
		$this->collection = xn("collection");
		 $db = $this->_mongo->selectDB($this->db);
		 $result = $db->command(['drop' => $this->collection]);
		
		
		$this->display();
	}

	/** list collection indexes **/
public function doCollectionIndexes() {
    $this->db = x("db");
    $this->collection = xn("collection");

    // get collection properly
    $collection = $this->_mongo->selectDB($this->db)->selectCollection($this->collection);

    $this->indexes = $collection->getIndexInfo();

    foreach ($this->indexes as $_index => $index) {
        $index["data"] = $this->_highlight($index["key"], "json");
        $this->indexes[$_index] = $index;
    }

    $this->display();
}


	/** drop a collection index **/
public function doDeleteIndex() {
    $this->db = x("db");
    $this->collection = xn("collection");

    // get collection properly
    $indexes = $this->_mongo->selectDB($this->db)->selectCollection($this->collection)->getIndexInfo();
   // $indexes = $this->_mongo->listIndexes($dbName, $collectionName);

   
   $manager = null;
    if (property_exists($this->_mongo, '_mongo')) {
        $ref = new ReflectionClass($this->_mongo);
        if ($ref->hasProperty('_mongo')) {
            $prop = $ref->getProperty('_mongo');
            $prop->setAccessible(true);
            $manager = $prop->getValue($this->_mongo);
        }
    }

    if (!$manager instanceof MongoDB\Driver\Manager) {
        throw new Exception("MongoDB Manager not found inside RMongo instance");
    }
   
    $targetIndex = trim(xn("index"));
    foreach ($indexes as $index) {
        if ($index["name"] == $targetIndex) {
            
             $cmd = [
        "dropIndexes" =>  $this->collection,
                "index" => $index["name"]
    ];
            
             $command = new MongoDB\Driver\Command($cmd);
    $cursor = $manager->executeCommand($this->db, $command);
            
           
            break;
        }
    }

    // ✅ Redirect after deletion
    $this->redirect("collection.collectionIndexes", [
        "db" =>  $this->db,
        "collection" =>  $this->collection
    ]);
}


	/** create a collection index **/
public function doCreateIndex() {
    // Get database and collection names from request
    $dbName = x("db");
    $this->db=$dbName;
    $collectionName = xn("collection");
$this->collection=$collectionName;
    // Get fields from RMongo helper
    $this->nativeFields = MCollection::fields(
        $this->_mongo->selectDB($dbName),
        $collectionName
    );

    if ($this->isPost()) {
       
        // Get db and collection objects safely (not assigned to $this->db)
     //  $collection = $this->_mongo->selectCollection($dbName, $collectionName);
       $collection = $this->_mongo->selectDB($this->db)->selectCollection($this->collection);
       
        // Get fields and orders from POST
        $fields = xn("field");
        if (!is_array($fields)) {
            $this->message = "Index contains one field at least.";
            $this->display();
            return;
        }

        $orders = xn("order");
        $attrs = [];
        foreach ($fields as $index => $field) {
            $field = trim($field);
            if (!empty($field)) {
                $attrs[$field] = ($orders[$index] == "asc") ? 1 : -1;
            }
        }

        if (empty($attrs)) {
            $this->message = "Index contains one field at least.";
            $this->display();
            return;
        }

        // Build index options
        $options = ["background" => true];
        if (x("is_unique")) {
            $options["unique"] = true;
            if (x("drop_duplicate")) {
                $options["dropDups"] = true;
            }
        }

        $name = trim(xn("name"));
        if (!empty($name)) {
            $options["name"] = $name;
        }

        // Use RMongo method for index creation
        try {
            $collection->ensureIndex($attrs, $options);
        } catch (Exception $e) {
            $this->message = "Failed to create index: " . $e->getMessage();
            $this->display();
            return;
        }

        // Redirect safely
        $this->redirect("collection.collectionIndexes", [
            "db" => $dbName,
            "collection" => $collectionName
        ]);
        return;
    }

    $this->display();
}
	/** create a collection index **/
	public function doCreate2DIndex() {
		$this->db = x("db");
		$this->collection = xn("collection");
		$this->nativeFields = MCollection::fields($this->_mongo->selectDB($this->db), $this->collection);
		if ($this->isPost()) {
			$collection = $this->_mongo->selectDB($this->db)->selectCollection($this->collection);
       
			$attrs = array();

			//Location Field
			$locationField = trim(xn("location_field"));
			$attrs[$locationField] = "2d";

			//Other Fields
			$fields = xn("field");
			if (!is_array($fields)) {
				$this->message = "Index contains one field at least.";
				$this->display();
				return;
			}
			$orders = xn("order");

			foreach ($fields as $index => $field) {
				$field = trim($field);
				if (!empty($field)) {
					$attrs[$field] = ($orders[$index] == "asc") ? 1 : -1;
				}
			}
			if (empty($attrs)) {
				$this->message = "Index contains one field at least.";
				$this->display();
				return;
			}

			//Options
			$options = array();
			$minBound = x("min_bound");
			if (is_numeric($minBound)) {
				$minBound = floatval($minBound);
				$options["min"] = $minBound;
			}
			$maxBound = x("max_bound");
			if (is_numeric($maxBound)) {
				$maxBound = floatval($maxBound);
				$options["max"] = $maxBound;
			}
			$bits = x("bits");
			if (is_numeric($bits)) {
				$bits = intval($bits);
				$options["bits"] = $bits;
			}


			//name
			$name = trim(xn("name"));
			if (!empty($name)) {
				$options["name"] = $name;
			}
			$collection->ensureIndex($attrs, $options);

			$this->redirect("collection.collectionIndexes", array(
					"db" => $this->db,
					"collection" => $this->collection
			));
		}

		$this->display();
	}

	/** collection statistics **/
	public function doCollectionStats() {
		$this->db = x("db");
		$this->collection = xn("collection");
		$this->stats = array();

		$db = $this->_mongo->selectDB($this->db);
		$ret = $db->command(array( "collStats" => $this->collection ));
		if ($ret["ok"]) {
			$this->stats = $ret;
			foreach ($this->stats as $index => $stat) {
				if (is_array($stat) || is_bool($stat)) {
					$this->stats[$index] = $this->_highlight($stat, "json");
				}
			}
		}

		//top
		$ret = $this->_mongo->selectDB("admin")->command(array( "top" => 1 ));
		$this->top = array();
		$namespace = $this->db . "." . $this->collection;
		if ($ret["ok"] && !empty($ret["totals"][$namespace])) {
			$this->top = $ret["totals"][$namespace];
			foreach ($this->top as $index => $value) {
				$this->top[$index] = $value["count"];
			}
		}
		$this->display();
	}

	/** validate collection **/
public function doCollectionValidate() {
    $this->db = x("db");
    $this->collection = xn("collection");

    try {
        // Get MongoDB Manager from RMongo (no new class)
        $ref = new ReflectionClass($this->_mongo);
        $prop = $ref->getProperty('_mongo');
        $prop->setAccessible(true);
        $manager = $prop->getValue($this->_mongo);

        if (!$manager instanceof MongoDB\Driver\Manager) {
            throw new Exception("MongoDB Manager not initialized in RMongo");
        }

        // Build and execute the validate command
        $cmd = new MongoDB\Driver\Command([
            "validate" => $this->collection,
            "full" => true
        ]);

        $cursor = $manager->executeCommand($this->db, $cmd);
        $result = current($cursor->toArray());

        // Prepare output for UI
        $this->ret = $this->_highlight((array)$result, "json");

    } catch (Exception $e) {
        $this->error = "Validation failed: " . $e->getMessage();
    }

    $this->display();
}


	/** rename collection **/
public function doCollectionRename() {
    $dbName = xn("db");
    $collectionName = xn("collection");
    $this->realName = $collectionName;
    $this->db = $dbName;

    if ($this->isPost()) {
        $oldname = trim(xn("oldname"));
        $newname = trim(xn("newname"));
        $removeExists = (bool) xn("remove_exists");

        if ($newname === "") {
            $this->error = "Please enter a new name.";
            $this->display();
            return;
        }

        // ✅ Check if collection with new name already exists (only if removeExists is false)
        if (!$removeExists) {
            $collections = $this->_mongo->selectDB($this->db)->listCollections();
            foreach ($collections as $col) {
                if (is_array($col) && isset($col['name']) && $col['name'] == $newname) {
                    $this->error = "There is already a '{$newname}' collection. Drop it before renaming.";
                    $this->display();
                    return;
                }
            }
        }

        try {
            // ✅ Rename command (must run in 'admin' DB)
            $cmd = [
                "renameCollection" => "{$dbName}.{$oldname}",
                "to" => "{$dbName}.{$newname}",
                "dropTarget" => $removeExists,
            ];

            // ✅ Get MongoDB Manager from RMongo
            $manager = null;
            if (property_exists($this->_mongo, '_mongo')) {
                $ref = new ReflectionClass($this->_mongo);
                if ($ref->hasProperty('_mongo')) {
                    $prop = $ref->getProperty('_mongo');
                    $prop->setAccessible(true);
                    $manager = $prop->getValue($this->_mongo);
                }
            }

            if (!$manager instanceof MongoDB\Driver\Manager) {
                throw new Exception("MongoDB Manager not found inside RMongo instance");
            }

            // ✅ Execute rename command
            $command = new MongoDB\Driver\Command($cmd);
            $cursor = $manager->executeCommand('admin', $command);

            // ✅ Convert the cursor result safely to array
            $resultArr = $cursor->toArray();
            if (!empty($resultArr)) {
                $this->ret = (array) $resultArr[0]; // force first document into array
            } else {
                $this->ret = ["ok" => 0, "errmsg" => "No result returned"];
            }

            // ✅ Handle result
            if (isset($this->ret["ok"]) && $this->ret["ok"] == 1) {
                $this->realName = $newname;
                $this->message = "Collection renamed successfully. <a href=\"?action=collection.index&db={$dbName}&collection={$newname}\">[GO &raquo;]</a>";
            } else {
                $errmsg = isset($this->ret["errmsg"]) ? $this->ret["errmsg"] : "Unknown error";
                $this->error = "Rename operation failed: " . $errmsg;
            }

            $this->ret_json = $this->_highlight($this->ret, "json");

        } catch (Exception $e) {
            $this->error = "Rename failed: " . $e->getMessage();
        }
    }

    $this->display();
}

	/** collection properties **/
public function doCollectionProps() {
    $this->db = xn("db");
    $this->collection = xn("collection");

    try {
        // === Get the MongoDB Manager instance from RMongo ===
        $ref = new ReflectionClass($this->_mongo);
        $prop = $ref->getProperty('_mongo');
        $prop->setAccessible(true);
        $manager = $prop->getValue($this->_mongo);

        if (!$manager instanceof MongoDB\Driver\Manager) {
            throw new Exception("MongoDB Manager not initialized in RMongo");
        }

        // === Step 1: Get collection properties via listCollections ===
        $cmd = new MongoDB\Driver\Command(["listCollections" => 1, "filter" => ["name" => $this->collection]]);
        $cursor = $manager->executeCommand($this->db, $cmd);
        $info = current($cursor->toArray());

        $this->isCapped = 0;
        $this->size = 0;
        $this->max = 0;

        if (isset($info->options->capped)) {
            $this->isCapped = $info->options->capped;
        }
        if (isset($info->options->size)) {
            $this->size = $info->options->size;
        }
        if (isset($info->options->max)) {
            $this->max = $info->options->max;
        }

        // === Step 2: If POST, modify collection ===
        if ($this->isPost()) {
            $this->isCapped = xi("is_capped");
            $this->size = xi("size");
            $this->max = xi("max");

            $bkCollection = $this->collection . "_rockmongo_bk_" . uniqid();

            // Rename current collection to backup (must run in admin DB)
            $renameCmd = [
                "renameCollection" => "{$this->db}.{$this->collection}",
                "to" => "{$this->db}.{$bkCollection}",
                "dropTarget" => true
            ];
            $cursor = $manager->executeCommand("admin", new MongoDB\Driver\Command($renameCmd));
            $ret = current($cursor->toArray());

            if (empty($ret->ok)) {
                $this->error = "Rename failed: <font color='red'>{$ret->errmsg}</font>";
                $this->display();
                return;
            }

            // Create new capped collection if requested
            $createCmd = [
                "create" => $this->collection,
                "capped" => (bool)$this->isCapped,
                "size" => (int)$this->size,
                "max" => (int)$this->max
            ];
            $manager->executeCommand($this->db, new MongoDB\Driver\Command($createCmd));

            // Copy data from backup → new collection
            $srcNs = "{$this->db}.{$bkCollection}";
            $dstNs = "{$this->db}.{$this->collection}";

            $aggCmd = [
                "aggregate" => $bkCollection,
                "pipeline" => [
                    ["\$out" => $this->collection]
                ],
                "cursor" => new stdClass()
            ];
            $manager->executeCommand($this->db, new MongoDB\Driver\Command($aggCmd));

            // Drop backup collection
            $dropCmd = ["drop" => $bkCollection];
            $manager->executeCommand($this->db, new MongoDB\Driver\Command($dropCmd));
        }

    } catch (Exception $e) {
        $this->error = "Operation failed: " . $e->getMessage();
    }

    $this->display();
}
/** duplicate collection **/
public function doCollectionDuplicate() {
    $this->db = xn("db");
    $this->collection = xn("collection");

    if (!$this->isPost()) {
        x("target", $this->collection . "_copy");
        x("remove_target", 1);
        x("copy_indexes", 1);
        $this->display();
        return;
    }

    $target = trim(xn("target"));
    $removeTarget = x("remove_target");
    $copyIndexes = x("copy_indexes");

    if ($target === "") {
        $this->error = "Please enter a valid target.";
        $this->display();
        return;
    }

    try {
        // Access manager from RMongo
        $ref = new ReflectionClass($this->_mongo);
        $prop = $ref->getProperty('_mongo');
        $prop->setAccessible(true);
        $manager = $prop->getValue($this->_mongo);

        if (!$manager instanceof MongoDB\Driver\Manager) {
            throw new Exception("MongoDB Manager not initialized.");
        }

        // Remove existing target collection if requested
        if ($removeTarget) {
            $dropCmd = new MongoDB\Driver\Command(['drop' => $target]);
            try {
                $manager->executeCommand($this->db, $dropCmd);
            } catch (Exception $e) {
                // Ignore if collection doesn't exist
            }
        }

        // Copy all documents
        $srcQuery = new MongoDB\Driver\Query([]);
        $cursor = $manager->executeQuery("$this->db.$this->collection", $srcQuery);

        $bulk = new MongoDB\Driver\BulkWrite;
        $count = 0;
        foreach ($cursor as $doc) {
            $arr = (array)$doc;
            unset($arr['_id']); // remove _id before insert
            $bulk->insert($arr);
            $count++;
        }

        if ($count > 0) {
            $manager->executeBulkWrite("$this->db.$target", $bulk);
        }

        // Copy indexes if requested
        if ($copyIndexes) {
            $indexCmd = new MongoDB\Driver\Command(['listIndexes' => $this->collection]);
            $cursor = $manager->executeCommand($this->db, $indexCmd);
            foreach ($cursor as $index) {
                $idx = (array)$index;
                if ($idx['name'] == '_id_') continue;
                unset($idx['v'], $idx['ns'], $idx['background']);
                $createIndexCmd = new MongoDB\Driver\Command([
                    'createIndexes' => $target,
                    'indexes' => [[
                        'key' => (array)$idx['key'],
                        'name' => $idx['name']
                    ]]
                ]);
                $manager->executeCommand($this->db, $createIndexCmd);
            }
        }

        if ($count > 0)
            $this->message = "Collection duplicated successfully ($count documents copied).";
        else
            $this->message = "Collection duplicated successfully (no documents found).";

    } catch (Exception $e) {
        $this->error = "Duplication failed: " . $e->getMessage();
    }

    $this->display();
}

	/** transfer a collection **/
	public function doCollectionTransfer() {
		$this->redirect("db.dbTransfer", array(
			"db" => xn("db"),
			"collection" => xn("collection")
		));
	}

	/** export a collection **/
	public function doCollectionExport() {
		$this->redirect("db.dbExport", array( "db" => xn("db"), "collection" => xn("collection"), "can_download" => xn("can_download") ));
	}

	/** import a collection **/
	public function doCollectionImport() {
		$this->redirect("db.dbImport", array( "db" => xn("db") ));
	}
	
	
	
	
}

?>